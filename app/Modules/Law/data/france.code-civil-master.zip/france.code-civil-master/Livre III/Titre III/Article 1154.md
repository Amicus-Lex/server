Article 1154
----
Les intérêts échus des capitaux peuvent produire des intérêts, ou par une
demande judiciaire, ou par une convention spéciale, pourvu que, soit dans la
demande, soit dans la convention, il s'agisse d'intérêts dus au moins pour une
année entière.
