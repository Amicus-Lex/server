Article 1113
----
La violence est une cause de nullité du contrat, non seulement lorsqu'elle a été
exercée sur la partie contractante, mais encore lorsqu'elle l'a été sur son
époux ou sur son épouse, sur ses descendants ou ses ascendants.
