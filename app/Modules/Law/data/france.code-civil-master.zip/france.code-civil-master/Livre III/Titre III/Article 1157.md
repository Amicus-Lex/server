Article 1157
----
Lorsqu'une clause est susceptible de deux sens, on doit plutôt l'entendre dans
celui avec lequel elle peut avoir quelque effet, que dans le sens avec lequel
elle n'en pourrait produire aucun.
