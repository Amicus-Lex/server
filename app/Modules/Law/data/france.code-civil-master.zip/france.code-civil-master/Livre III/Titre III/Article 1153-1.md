Article 1153-1
----
En toute matière, la condamnation à une indemnité emporte intérêts au taux légal
même en l'absence de demande ou de disposition spéciale du jugement. Sauf
disposition contraire de la loi, ces intérêts courent à compter du prononcé du
jugement à moins que le juge n'en décide autrement.

En cas de confirmation pure et simple par le juge d'appel d'une décision
allouant une indemnité en réparation d'un dommage, celle-ci porte de plein droit
intérêt au taux légal à compter du jugement de première instance. Dans les
autres cas, l'indemnité allouée en appel porte intérêt à compter de la décision
d'appel. Le juge d'appel peut toujours déroger aux dispositions du présent
alinéa.
