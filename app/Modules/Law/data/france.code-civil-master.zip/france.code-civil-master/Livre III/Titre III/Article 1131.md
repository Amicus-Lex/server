Article 1131
----
L'obligation sans cause, ou sur une fausse cause, ou sur une cause illicite, ne
peut avoir aucun effet.
