Article 1134
----
Les conventions légalement formées tiennent lieu de loi à ceux qui les ont
faites.

Elles ne peuvent être révoquées que de leur consentement mutuel, ou pour les
causes que la loi autorise.

Elles doivent être exécutées de bonne foi.
