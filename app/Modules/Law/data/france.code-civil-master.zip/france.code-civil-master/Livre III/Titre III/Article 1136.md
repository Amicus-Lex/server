Article 1136
----
L'obligation de donner emporte celle de livrer la chose et de la conserver
jusqu'à la livraison, à peine de dommages et intérêts envers le créancier.
