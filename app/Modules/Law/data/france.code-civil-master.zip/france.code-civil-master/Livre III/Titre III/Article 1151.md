Article 1151
----
Dans le cas même où l'inexécution de la convention résulte du dol du débiteur,
les dommages et intérêts ne doivent comprendre à l'égard de la perte éprouvée
par le créancier et du gain dont il a été privé, que ce qui est une suite
immédiate et directe de l'inexécution de la convention.
