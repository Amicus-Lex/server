Article 1140
----
Les effets de l'obligation de donner ou de livrer un immeuble sont réglés au
titre "De la vente" et au titre "Des privilèges et hypothèques".
