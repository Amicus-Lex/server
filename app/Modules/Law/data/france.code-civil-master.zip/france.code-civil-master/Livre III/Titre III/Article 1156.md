Article 1156
----
On doit dans les conventions rechercher quelle a été la commune intention des
parties contractantes, plutôt que de s'arrêter au sens littéral des termes.
