Article 1148
----
Il n'y a lieu à aucuns dommages et intérêts lorsque, par suite d'une force
majeure ou d'un cas fortuit, le débiteur a été empêché de donner ou de faire ce
à quoi il était obligé, ou a fait ce qui lui était interdit.
