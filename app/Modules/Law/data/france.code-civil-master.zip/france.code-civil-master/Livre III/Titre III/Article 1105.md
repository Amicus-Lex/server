Article 1105
----
Le contrat de bienfaisance est celui dans lequel l'une des parties procure à
l'autre un avantage purement gratuit.
