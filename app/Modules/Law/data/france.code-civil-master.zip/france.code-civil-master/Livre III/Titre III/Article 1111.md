Article 1111
----
La violence exercée contre celui qui a contracté l'obligation est une cause de
nullité, encore qu'elle ait été exercée par un tiers autre que celui au profit
duquel la convention a été faite.
