Article 1102
----
Le contrat est synallagmatique ou bilatéral lorsque les contractants s'obligent
réciproquement les uns envers les autres.
