Article 1114
----
La seule crainte révérencielle envers le père, la mère, ou autre ascendant, sans
qu'il y ait eu de violence exercée, ne suffit point pour annuler le contrat.
