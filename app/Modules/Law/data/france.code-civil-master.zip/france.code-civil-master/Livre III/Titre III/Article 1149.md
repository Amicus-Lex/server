Article 1149
----
Les dommages et intérêts dus au créancier sont, en général, de la perte qu'il a
faite et du gain dont il a été privé, sauf les exceptions et modifications ci-
après.
