Article 1127
----
Le simple usage ou la simple possession d'une chose peut être, comme la chose
même, l'objet du contrat.
