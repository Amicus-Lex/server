Article 1119
----
On ne peut, en général, s'engager, ni stipuler en son propre nom, que pour soi-
même.
