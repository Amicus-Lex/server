Article 1141
----
Si la chose qu'on s'est obligé de donner ou de livrer à deux personnes
successivement est purement mobilière, celle des deux qui en a été mise en
possession réelle est préférée et en demeure propriétaire, encore que son titre
soit postérieur en date, pourvu toutefois que la possession soit de bonne foi.
