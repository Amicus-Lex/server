Article 1125-1
----
Sauf autorisation de justice, il est interdit, à peine de nullité, à quiconque
exerce une fonction ou occupe un emploi dans un établissement hébergeant des
personnes âgées ou dispensant des soins psychiatriques de se rendre acquéreur
d'un bien ou cessionnaire d'un droit appartenant à une personne admise dans
l'établissement, non plus que de prendre à bail le logement occupé par cette
personne avant son admission dans l'établissement.

Pour l'application du présent article, sont réputées personnes interposées, le
conjoint, les ascendants et les descendants des personnes auxquelles
s'appliquent les interdictions ci-dessus édictées.
