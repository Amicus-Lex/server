Article 1125
----
Les personnes capables de s'engager ne peuvent opposer l'incapacité de ceux avec
qui elles ont contracté.
