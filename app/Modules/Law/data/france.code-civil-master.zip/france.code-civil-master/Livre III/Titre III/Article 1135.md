Article 1135
----
Les conventions obligent non seulement à ce qui y est exprimé, mais encore à
toutes les suites que l'équité, l'usage ou la loi donnent à l'obligation d'après
sa nature.
