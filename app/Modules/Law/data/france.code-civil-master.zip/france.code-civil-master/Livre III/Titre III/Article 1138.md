Article 1138
----
L'obligation de livrer la chose est parfaite par le seul consentement des
parties contractantes.

Elle rend le créancier propriétaire et met la chose à ses risques dès l'instant
où elle a dû être livrée, encore que la tradition n'en ait point été faite, à
moins que le débiteur ne soit en demeure de la livrer ; auquel cas la chose
reste aux risques de ce dernier.
