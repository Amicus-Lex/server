Article 1106
----
Le contrat à titre onéreux est celui qui assujettit chacune des parties à donner
ou à faire quelque chose.
