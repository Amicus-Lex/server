Article 1155
----
Néanmoins, les revenus échus, tels que fermages, loyers, arrérages de rentes
perpétuelles ou viagères, produisent intérêt du jour de la demande ou de la
convention.

La même règle s'applique aux restitutions de fruits, et aux intérêts payés par
un tiers aux créanciers en acquit du débiteur.
