Article 1137
----
L'obligation de veiller à la conservation de la chose, soit que la convention
n'ait pour objet que l'utilité de l'une des parties, soit qu'elle ait pour objet
leur utilité commune, soumet celui qui en est chargé à y apporter tous les soins
raisonnables.

Cette obligation est plus ou moins étendue relativement à certains contrats,
dont les effets, à cet égard, sont expliqués sous les titres qui les concernent.
