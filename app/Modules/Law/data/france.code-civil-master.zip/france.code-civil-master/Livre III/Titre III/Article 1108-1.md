Article 1108-1
----
Lorsqu'un écrit est exigé pour la validité d'un acte juridique, il peut être
établi et conservé sous forme électronique dans les conditions prévues aux
articles 1316-1 et 1316-4 et, lorsqu'un acte authentique est requis, au second
alinéa de l'article 1317.

Lorsqu'est exigée une mention écrite de la main même de celui qui s'oblige, ce
dernier peut l'apposer sous forme électronique si les conditions de cette
apposition sont de nature à garantir qu'elle ne peut être effectuée que par lui-
même.
