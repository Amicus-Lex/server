Article 1122
----
On est censé avoir stipulé pour soi et pour ses héritiers et ayants cause, à
moins que le contraire ne soit exprimé ou ne résulte de la nature de la
convention.
