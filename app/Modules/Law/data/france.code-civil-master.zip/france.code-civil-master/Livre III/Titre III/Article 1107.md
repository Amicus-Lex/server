Article 1107
----
Les contrats, soit qu'ils aient une dénomination propre, soit qu'ils n'en aient
pas, sont soumis à des règles générales, qui sont l'objet du présent titre.

Les règles particulières à certains contrats sont établies sous les titres
relatifs à chacun d'eux ; et les règles particulières aux transactions
commerciales sont établies par les lois relatives au commerce.
