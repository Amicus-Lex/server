Article 1101
----
Le contrat est une convention par laquelle une ou plusieurs personnes
s'obligent, envers une ou plusieurs autres, à donner, à faire ou à ne pas faire
quelque chose.
