Article 1118
----
La lésion ne vicie les conventions que dans certains contrats ou à l'égard de
certaines personnes, ainsi qu'il sera expliqué en la même section.
