Article 1159
----
Ce qui est ambigu s'interprète par ce qui est d'usage dans le pays où le contrat
est passé.
