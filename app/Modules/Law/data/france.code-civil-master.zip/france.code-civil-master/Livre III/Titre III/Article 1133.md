Article 1133
----
La cause est illicite, quand elle est prohibée par la loi, quand elle est
contraire aux bonnes moeurs ou à l'ordre public.
