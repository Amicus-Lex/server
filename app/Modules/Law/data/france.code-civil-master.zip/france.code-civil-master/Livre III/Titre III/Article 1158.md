Article 1158
----
Les termes susceptibles de deux sens doivent être pris dans le sens qui convient
le plus à la matière du contrat.
