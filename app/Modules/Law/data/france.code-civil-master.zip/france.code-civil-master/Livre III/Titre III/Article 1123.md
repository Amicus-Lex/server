Article 1123
----
Toute personne peut contracter si elle n'en est pas déclarée incapable par la
loi.
