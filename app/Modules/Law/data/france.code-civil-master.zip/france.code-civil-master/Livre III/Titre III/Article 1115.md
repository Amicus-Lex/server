Article 1115
----
Un contrat ne peut plus être attaqué pour cause de violence, si, depuis que la
violence a cessé, ce contrat a été approuvé soit expressément, soit tacitement,
soit en laissant passer le temps de la restitution fixé par la loi.
