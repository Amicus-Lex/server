Article 1139
----
Le débiteur est constitué en demeure, soit par une sommation ou par autre acte
équivalent, telle une lettre missive lorsqu'il ressort de ses termes une
interpellation suffisante, soit par l'effet de la convention, lorsqu'elle porte
que, sans qu'il soit besoin d'acte et par la seule échéance du terme, le
débiteur sera en demeure.
