Article 1116
----
Le dol est une cause de nullité de la convention lorsque les manoeuvres
pratiquées par l'une des parties sont telles, qu'il est évident que, sans ces
manoeuvres, l'autre partie n'aurait pas contracté.

Il ne se présume pas et doit être prouvé.
