Article 1161
----
Toutes les clauses des conventions s'interprètent les unes par les autres, en
donnant à chacune le sens qui résulte de l'acte entier.
