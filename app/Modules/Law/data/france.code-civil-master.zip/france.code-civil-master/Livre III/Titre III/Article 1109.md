Article 1109
----
Il n'y a point de consentement valable si le consentement n'a été donné que par
erreur ou s'il a été extorqué par violence ou surpris par dol.
