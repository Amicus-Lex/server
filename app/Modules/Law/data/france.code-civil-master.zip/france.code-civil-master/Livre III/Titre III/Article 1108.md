Article 1108
----
Quatre conditions sont essentielles pour la validité d'une convention :

Le consentement de la partie qui s'oblige ;

Sa capacité de contracter ;

Un objet certain qui forme la matière de l'engagement ;

Une cause licite dans l'obligation.
