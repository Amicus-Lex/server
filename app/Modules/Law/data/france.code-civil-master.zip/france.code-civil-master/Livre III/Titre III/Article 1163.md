Article 1163
----
Quelque généraux que soient les termes dans lesquels une convention est conçue,
elle ne comprend que les choses sur lesquelles il paraît que les parties se sont
proposé de contracter.
