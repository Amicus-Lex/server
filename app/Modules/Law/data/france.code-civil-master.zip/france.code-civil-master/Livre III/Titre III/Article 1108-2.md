Article 1108-2
----
Il est fait exception aux dispositions de l'article 1108-1 pour :

1° Les actes sous seing privé relatifs au droit de la famille et des successions
;

2° Les actes sous seing privé relatifs à des sûretés personnelles ou réelles, de
nature civile ou commerciale, sauf s'ils sont passés par une personne pour les
besoins de sa profession.
