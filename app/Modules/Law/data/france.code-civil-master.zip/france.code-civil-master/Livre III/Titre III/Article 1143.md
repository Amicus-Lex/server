Article 1143
----
Néanmoins, le créancier a le droit de demander que ce qui aurait été fait par
contravention à l'engagement soit détruit ; et il peut se faire autoriser à le
détruire aux dépens du débiteur, sans préjudice des dommages et intérêts s'il y
a lieu.
