Article 1142
----
Toute obligation de faire ou de ne pas faire se résout en dommages et intérêts
en cas d'inexécution de la part du débiteur.
