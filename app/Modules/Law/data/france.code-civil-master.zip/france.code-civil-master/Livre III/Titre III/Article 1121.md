Article 1121
----
On peut pareillement stipuler au profit d'un tiers lorsque telle est la
condition d'une stipulation que l'on fait pour soi-même ou d'une donation que
l'on fait à un autre. Celui qui a fait cette stipulation ne peut plus la
révoquer si le tiers a déclaré vouloir en profiter.
