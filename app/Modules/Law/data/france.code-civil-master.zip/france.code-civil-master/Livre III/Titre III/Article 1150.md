Article 1150
----
Le débiteur n'est tenu que des dommages et intérêts qui ont été prévus ou qu'on
a pu prévoir lors du contrat, lorsque ce n'est point par son dol que
l'obligation n'est point exécutée.
