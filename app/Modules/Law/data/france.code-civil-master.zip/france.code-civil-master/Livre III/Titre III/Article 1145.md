Article 1145
----
Si l'obligation est de ne pas faire, celui qui y contrevient doit des dommages
et intérêts par le seul fait de la contravention.
