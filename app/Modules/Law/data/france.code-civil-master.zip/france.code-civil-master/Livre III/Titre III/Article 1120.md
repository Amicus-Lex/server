Article 1120
----
Néanmoins, on peut se porter fort pour un tiers, en promettant le fait de celui-
ci ; sauf l'indemnité contre celui qui s'est porté fort ou qui a promis de faire
ratifier, si le tiers refuse de tenir l'engagement.
