Article 1146
----
Les dommages et intérêts ne sont dus que lorsque le débiteur est en demeure de
remplir son obligation, excepté néanmoins lorsque la chose que le débiteur
s'était obligé de donner ou de faire ne pouvait être donnée ou faite que dans un
certain temps qu'il a laissé passer. La mise en demeure peut résulter d'une
lettre missive, s'il en ressort une interpellation suffisante.
