Article 1103
----
Il est unilatéral lorsqu'une ou plusieurs personnes sont obligées envers une ou
plusieurs autres, sans que de la part de ces dernières il y ait d'engagement.
