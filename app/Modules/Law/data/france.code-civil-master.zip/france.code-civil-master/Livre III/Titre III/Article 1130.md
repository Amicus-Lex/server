Article 1130
----
Les choses futures peuvent être l'objet d'une obligation.

On ne peut cependant renoncer à une succession non ouverte, ni faire aucune
stipulation sur une pareille succession, même avec le consentement de celui de
la succession duquel il s'agit, que dans les conditions prévues par la loi.
