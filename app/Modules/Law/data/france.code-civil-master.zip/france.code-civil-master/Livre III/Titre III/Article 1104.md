Article 1104
----
Il est commutatif lorsque chacune des parties s'engage à donner ou à faire une
chose qui est regardée comme l'équivalent de ce qu'on lui donne, ou de ce qu'on
fait pour elle.

Lorsque l'équivalent consiste dans la chance de gain ou de perte pour chacune
des parties, d'après un événement incertain, le contrat est aléatoire.
