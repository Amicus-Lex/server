Article 1110
----
L'erreur n'est une cause de nullité de la convention que lorsqu'elle tombe sur
la substance même de la chose qui en est l'objet.

Elle n'est point une cause de nullité lorsqu'elle ne tombe que sur la personne
avec laquelle on a intention de contracter, à moins que la considération de
cette personne ne soit la cause principale de la convention.
