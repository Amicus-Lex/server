Article 1160
----
On doit suppléer dans le contrat les clauses qui y sont d'usage, quoiqu'elles
n'y soient pas exprimées.
