Article 1147
----
Le débiteur est condamné, s'il y a lieu, au paiement de dommages et intérêts,
soit à raison de l'inexécution de l'obligation, soit à raison du retard dans
l'exécution, toutes les fois qu'il ne justifie pas que l'inexécution provient
d'une cause étrangère qui ne peut lui être imputée, encore qu'il n'y ait aucune
mauvaise foi de sa part.
