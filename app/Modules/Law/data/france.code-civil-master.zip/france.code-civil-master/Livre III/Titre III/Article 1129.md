Article 1129
----
Il faut que l'obligation ait pour objet une chose au moins déterminée quant à
son espèce.

La quotité de la chose peut être incertaine, pourvu qu'elle puisse être
déterminée.
