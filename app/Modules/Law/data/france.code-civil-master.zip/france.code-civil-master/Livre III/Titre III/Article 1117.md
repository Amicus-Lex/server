Article 1117
----
La convention contractée par erreur, violence ou dol, n'est point nulle de plein
droit ; elle donne seulement lieu à une action en nullité ou en rescision, dans
les cas et de la manière expliqués à la section VII du chapitre V du présent
titre.
