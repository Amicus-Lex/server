Article 1128
----
Il n'y a que les choses qui sont dans le commerce qui puissent être l'objet des
conventions.
