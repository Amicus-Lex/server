Article 1152
----
Lorsque la convention porte que celui qui manquera de l'exécuter payera une
certaine somme à titre de dommages-intérêts, il ne peut être alloué à l'autre
partie une somme plus forte, ni moindre.

Néanmoins, le juge peut, même d'office, modérer ou augmenter la peine qui avait
été convenue, si elle est manifestement excessive ou dérisoire. Toute
stipulation contraire sera réputée non écrite.
