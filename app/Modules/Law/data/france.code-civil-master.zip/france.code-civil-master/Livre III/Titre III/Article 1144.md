Article 1144
----
Le créancier peut aussi, en cas d'inexécution, être autorisé à faire exécuter
lui-même l'obligation aux dépens du débiteur. Celui-ci peut être condamné à
faire l'avance des sommes nécessaires à cette exécution.
