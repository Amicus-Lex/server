Article 1153
----
Dans les obligations qui se bornent au paiement d'une certaine somme, les
dommages-intérêts résultant du retard dans l'exécution ne consistent jamais que
dans la condamnation aux intérêts au taux légal, sauf les règles particulières
au commerce et au cautionnement.

Ces dommages et intérêts sont dus sans que le créancier soit tenu de justifier
d'aucune perte.

Ils ne sont dus que du jour de la sommation de payer, ou d'un autre acte
équivalent telle une lettre missive s'il en ressort une interpellation
suffisante, excepté dans le cas où la loi les fait courir de plein droit.

Le créancier auquel son débiteur en retard a causé, par sa mauvaise foi, un
préjudice indépendant de ce retard, peut obtenir des dommages et intérêts
distincts des intérêts moratoires de la créance.
