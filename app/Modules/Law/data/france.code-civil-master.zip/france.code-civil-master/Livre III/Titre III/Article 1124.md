Article 1124
----
Sont incapables de contracter, dans la mesure définie par la loi :

Les mineurs non émancipés ;

Les majeurs protégés au sens de l'article 488 du présent code.
