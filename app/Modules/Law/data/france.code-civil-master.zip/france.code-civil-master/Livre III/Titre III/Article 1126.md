Article 1126
----
Tout contrat a pour objet une chose qu'une partie s'oblige à donner, ou qu'une
partie s'oblige à faire ou à ne pas faire.
