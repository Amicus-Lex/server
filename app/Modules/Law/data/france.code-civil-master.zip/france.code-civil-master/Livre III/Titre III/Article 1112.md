Article 1112
----
Il y a violence lorsqu'elle est de nature à faire impression sur une personne
raisonnable, et qu'elle peut lui inspirer la crainte d'exposer sa personne ou sa
fortune à un mal considérable et présent.

On a égard, en cette matière, à l'âge, au sexe et à la condition des personnes.
