Article 1132
----
La convention n'est pas moins valable, quoique la cause n'en soit pas exprimée.
