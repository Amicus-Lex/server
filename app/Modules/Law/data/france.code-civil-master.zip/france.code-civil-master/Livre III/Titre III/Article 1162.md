Article 1162
----
Dans le doute, la convention s'interprète contre celui qui a stipulé et en
faveur de celui qui a contracté l'obligation.
