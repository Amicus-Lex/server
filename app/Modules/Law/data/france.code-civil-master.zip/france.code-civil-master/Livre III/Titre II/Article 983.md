Article 983
----
Dans tous les cas, il est fait un double original des testaments mentionnés aux
articles 981 et 982.

Si cette formalité n'a pu être accomplie en raison de l'état de santé du
testateur, il est dressé une expédition du testament, signée par les témoins et
par les officiers instrumentaires, pour tenir lieu du second original. Il y est
fait mention des causes qui ont empêché de dresser le second original.

Dès que leur communication est possible, et dans le plus bref délai, les deux
originaux, ou l'original et l'expédition du testament, sont adressés par
courriers distincts, sous pli clos et cacheté, au ministre chargé de la défense
nationale ou de la mer, pour être déposés chez le notaire indiqué par le
testateur ou, à défaut d'indication, chez le président de la chambre des
notaires de l'arrondissement du dernier domicile du testateur.
