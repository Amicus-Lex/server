Article 1094-3
----
Les enfants ou descendants pourront, nonobstant toute stipulation contraire du
disposant, exiger, quant aux biens soumis à l'usufruit, qu'il soit dressé
inventaire des meubles ainsi qu'état des immeubles, qu'il soit fait emploi des
sommes et que les titres au porteur soient, au choix de l'usufruitier, convertis
en titres nominatifs ou déposés chez un dépositaire agréé.
