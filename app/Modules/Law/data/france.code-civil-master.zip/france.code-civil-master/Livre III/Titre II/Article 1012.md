Article 1012
----
Le légataire à titre universel sera tenu, comme le légataire universel, des
dettes et charges de la succession du testateur, personnellement pour sa part et
portion, et hypothécairement pour le tout.
