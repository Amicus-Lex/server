Article 933
----
Si le donataire est majeur, l'acceptation doit être faite par lui ou, en son
nom, par la personne fondée de sa procuration, portant pouvoir d'accepter la
donation faite, ou un pouvoir général d'accepter les donations qui auraient été
ou qui pourraient être faites.

Cette procuration devra être passée devant notaires ; et une expédition devra en
être annexée à la minute de la donation, à la minute de l'acceptation qui serait
faite par acte séparé.
