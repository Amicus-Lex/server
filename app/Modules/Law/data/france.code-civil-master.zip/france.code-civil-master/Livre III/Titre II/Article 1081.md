Article 1081
----
Toute donation entre vifs de biens présents, quoique faite par contrat de
mariage aux époux, ou à l'un d'eux, sera soumise aux règles générales prescrites
pour les donations faites à ce titre.

Elle ne pourra avoir lieu au profit des enfants à naître, si ce n'est dans les
cas énoncés au chapitre VI du présent titre.
