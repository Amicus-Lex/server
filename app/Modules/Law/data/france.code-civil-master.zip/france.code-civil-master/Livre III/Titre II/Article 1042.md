Article 1042
----
Le legs sera caduc si la chose léguée a totalement péri pendant la vie du
testateur.

Il en sera de même si elle a péri depuis sa mort, sans le fait et la faute de
l'héritier, quoique celui-ci ait été mis en retard de la délivrer, lorsqu'elle
eût également dû périr entre les mains du légataire.
