Article 1058
----
La libéralité résiduelle n'oblige pas le premier gratifié à conserver les biens
reçus. Elle l'oblige à transmettre les biens subsistants.

Lorsque les biens, objets de la libéralité résiduelle, ont été aliénés par le
premier gratifié, les droits du second bénéficiaire ne se reportent ni sur le
produit de ces aliénations ni sur les nouveaux biens acquis.
