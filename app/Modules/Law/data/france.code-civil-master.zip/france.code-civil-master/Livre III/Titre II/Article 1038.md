Article 1038
----
Toute aliénation, celle même par vente avec faculté de rachat ou par échange,
que fera le testateur de tout ou de partie de la chose léguée, emportera la
révocation du legs pour tout ce qui a été aliéné, encore que l'aliénation
postérieure soit nulle, et que l'objet soit rentré dans la main du testateur.
