Article 1076
----
La donation-partage ne peut avoir pour objet que des biens présents.

La donation et le partage peuvent être faits par actes séparés pourvu que le
disposant intervienne aux deux actes.
