Article 963
----
Les biens et droits compris dans la donation révoquée rentrent dans le
patrimoine du donateur, libres de toutes charges et hypothèques du chef du
donataire, sans qu'ils puissent demeurer affectés, même subsidiairement, à
l'hypothèque légale des époux ; il en est ainsi même si la donation a été faite
en faveur du mariage du donataire et insérée dans le contrat de mariage.
