Article 923
----
Il n'y aura jamais lieu à réduire les donations entre vifs, qu'après avoir
épuisé la valeur de tous les biens compris dans les dispositions testamentaires
; et lorsqu'il y aura lieu à cette réduction, elle se fera en commençant par la
dernière donation, et ainsi de suite en remontant des dernières aux plus
anciennes.
