Article 1061
----
Les dispositions prévues aux articles 1049, 1051, 1052, 1055 et 1056 sont
applicables aux libéralités résiduelles.
