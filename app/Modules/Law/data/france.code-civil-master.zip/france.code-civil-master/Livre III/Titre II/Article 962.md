Article 962
----
La donation peut pareillement être révoquée, même si le donataire est entré en
possession des biens donnés et qu'il y a été laissé par le donateur depuis la
survenance de l'enfant. Toutefois, le donataire n'est pas tenu de restituer les
fruits qu'il a perçus, de quelque nature qu'ils soient, si ce n'est du jour
auquel la naissance de l'enfant ou son adoption en la forme plénière lui a été
notifiée par exploit ou autre acte en bonne forme, même si la demande pour
rentrer dans les biens donnés a été formée après cette notification.
