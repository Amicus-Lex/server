Article 1016
----
Les frais de la demande en délivrance seront à la charge de la succession, sans
néanmoins qu'il puisse en résulter de réduction de la réserve légale.

Les droits d'enregistrement seront dus par le légataire.

Le tout, s'il n'en a été autrement ordonné par le testament.

Chaque legs pourra être enregistré séparément, sans que cet enregistrement
puisse profiter à aucun autre qu'au légataire ou à ses ayants cause.
