Article 953
----
La donation entre vifs ne pourra être révoquée que pour cause d'inexécution des
conditions sous lesquelles elle aura été faite, pour cause d'ingratitude, et
pour cause de survenance d'enfants.
