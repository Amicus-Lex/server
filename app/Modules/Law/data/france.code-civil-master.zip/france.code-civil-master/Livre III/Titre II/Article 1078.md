Article 1078
----
Nonobstant les règles applicables aux donations entre vifs, les biens donnés
seront, sauf convention contraire, évalués au jour de la donation-partage pour
l'imputation et le calcul de la réserve, à condition que tous les héritiers
réservataires vivants ou représentés au décès de l'ascendant aient reçu un lot
dans le partage anticipé et l'aient expressément accepté, et qu'il n'ait pas été
prévu de réserve d'usufruit portant sur une somme d'argent.
