Article 895
----
Le testament est un acte par lequel le testateur dispose, pour le temps où il
n'existera plus, de tout ou partie de ses biens ou de ses droits et qu'il peut
révoquer.
