Article 901
----
Pour faire une libéralité, il faut être sain d'esprit. La libéralité est nulle
lorsque le consentement a été vicié par l'erreur, le dol ou la violence.
