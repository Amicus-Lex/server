Article 1045
----
Il sera encore réputé fait conjointement quand une chose qui n'est pas
susceptible d'être divisée sans détérioration aura été donnée par le même acte à
plusieurs personnes, même séparément.
