Article 994
----
Le testament fait au cours d'un voyage maritime, en la forme prescrite par les
articles 988 et suivants, ne sera valable qu'autant que le testateur mourra à
bord ou dans les six mois après qu'il sera débarqué dans un lieu où il aura pu
le refaire dans les formes ordinaires.

Toutefois, si le testateur entreprend un nouveau voyage maritime avant
l'expiration de ce délai, le testament sera valable pendant la durée de ce
voyage et pendant un nouveau délai de six mois après que le testateur sera de
nouveau débarqué.
