Article 1049
----
La libéralité ainsi consentie ne peut produire son effet que sur des biens ou
des droits identifiables à la date de la transmission et subsistant en nature au
décès du grevé.

Lorsqu'elle porte sur des valeurs mobilières, la libéralité produit également
son effet, en cas d'aliénation, sur les valeurs mobilières qui y ont été
subrogées.

Lorsqu'elle concerne un immeuble, la charge grevant la libéralité est soumise à
publicité.
