Article 1092
----
Toute donation entre vifs de biens présents, faite entre époux par contrat de
mariage, ne sera point censée faite sous la condition de survie du donataire, si
cette condition n'est formellement exprimée ; et elle sera soumise à toutes les
règles et formes ci-dessus prescrites pour ces sortes de donations.
