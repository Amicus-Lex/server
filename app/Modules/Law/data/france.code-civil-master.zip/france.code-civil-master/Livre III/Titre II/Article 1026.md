Article 1026
----
L'exécuteur testamentaire peut être relevé de sa mission pour motifs graves par
le tribunal.
