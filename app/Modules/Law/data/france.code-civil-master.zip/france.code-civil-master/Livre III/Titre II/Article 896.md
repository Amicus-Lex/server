Article 896
----
La disposition par laquelle une personne est chargée de conserver et de rendre à
un tiers ne produit d'effet que dans le cas où elle est autorisée par la loi.
