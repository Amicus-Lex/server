Article 1094
----
L'époux, soit par contrat de mariage, soit pendant le mariage, pourra, pour le
cas où il ne laisserait point d'enfant ni de descendant, disposer en faveur de
l'autre époux en propriété, de tout ce dont il pourrait disposer en faveur d'un
étranger.
