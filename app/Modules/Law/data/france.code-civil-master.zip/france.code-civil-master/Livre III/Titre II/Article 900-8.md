Article 900-8
----
Est réputée non écrite toute clause par laquelle le disposant prive de la
libéralité celui qui mettrait en cause la validité d'une clause d'inaliénabilité
ou demanderait l'autorisation d'aliéner.
