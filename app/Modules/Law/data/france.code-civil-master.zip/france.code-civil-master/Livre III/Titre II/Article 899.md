Article 899
----
Il en sera de même de la disposition entre vifs ou testamentaire par laquelle
l'usufruit sera donné à l'un et la nue-propriété à l'autre.
