Article 981
----
Les testaments des militaires, des marins de l'Etat et des personnes employées à
la suite des armées pourront être reçus dans les cas et conditions prévus à
l'article 93 soit par un officier supérieur en présence de deux témoins ; soit
par deux commissaires des armées ; soit par un commissaire des armées en
présence de deux témoins ; soit enfin, dans un détachement isolé, par l'officier
commandant ce détachement, assisté de deux témoins, s'il n'existe pas dans le
détachement d'officier supérieur ou de commissaire des armées.

Le testament de l'officier commandant un détachement isolé pourra être reçu par
l'officier qui vient après lui dans l'ordre du service.

La faculté de tester dans les conditions prévues au présent article s'étendra
aux prisonniers chez l'ennemi.
