Article 941
----
Le défaut de publication pourra être opposé par toutes personnes ayant intérêt,
excepté toutefois celles qui sont chargées de faire faire la publication, ou
leurs ayants cause, et le donateur.
