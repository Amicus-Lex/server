Article 1093
----
La donation de biens à venir, ou de biens présents et à venir, faite entre époux
par contrat de mariage, soit simple, soit réciproque, sera soumise aux règles
établies par le chapitre précédent, à l'égard des donations pareilles qui leur
seront faites par un tiers, sauf qu'elle ne sera point transmissible aux enfants
issus du mariage, en cas de décès de l'époux donataire avant l'époux donateur.
