Article 979
----
En cas que le testateur ne puisse parler, mais qu'il puisse écrire, il pourra
faire un testament mystique, à la charge expresse que le testament sera signé de
lui et écrit par lui ou par un autre, qu'il le présentera au notaire et aux
témoins, et qu'en haut de l'acte de suscription il écrira, en leur présence, que
le papier qu'il présente est son testament et signera. Il sera fait mention dans
l'acte de suscription que le testateur a écrit et signé ces mots en présence du
notaire et des témoins et sera, au surplus, observé tout ce qui est prescrit par
l'article 976 et n'est pas contraire au présent article.

Dans tous les cas prévus au présent article ou aux articles précédents, le
testament mystique dans lequel n'auront point été observées les formalités
légales, et qui sera nul comme tel, vaudra cependant comme testament olographe
si toutes les conditions requises pour sa validité comme testament olographe
sont remplies, même s'il a été qualifié de testament mystique.
