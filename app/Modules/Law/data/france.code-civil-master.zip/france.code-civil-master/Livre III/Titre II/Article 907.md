Article 907
----
Le mineur, quoique parvenu à l'âge de seize ans, ne pourra, même par testament,
disposer au profit de son tuteur.

Le mineur, devenu majeur ou émancipé, ne pourra disposer, soit par donation
entre vifs, soit par testament, au profit de celui qui aura été son tuteur, si
le compte définitif de la tutelle n'a été préalablement rendu et apuré.

Sont exceptés, dans les deux cas ci-dessus, les ascendants des mineurs, qui sont
ou qui ont été leurs tuteurs.
