Article 973
----
Ce testament doit être signé par le testateur en présence des témoins et du
notaire ; si le testateur déclare qu'il ne sait ou ne peut signer, il sera fait
dans l'acte mention expresse de sa déclaration, ainsi que de la cause qui
l'empêche de signer.
