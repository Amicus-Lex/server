Article 913
----
Les libéralités, soit par actes entre vifs, soit par testament, ne pourront
excéder la moitié des biens du disposant, s'il ne laisse à son décès qu'un
enfant ; le tiers, s'il laisse deux enfants ; le quart, s'il en laisse trois ou
un plus grand nombre.

L'enfant qui renonce à la succession n'est compris dans le nombre d'enfants
laissés par le défunt que s'il est représenté ou s'il est tenu au rapport d'une
libéralité en application des dispositions de l'article 845.
