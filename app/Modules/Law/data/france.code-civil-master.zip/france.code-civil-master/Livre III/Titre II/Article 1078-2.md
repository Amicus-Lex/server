Article 1078-2
----
Les parties peuvent aussi convenir qu'une donation antérieure faite hors part
sera incorporée au partage et imputée sur la part de réserve du donataire à
titre d'avancement de part successorale.
