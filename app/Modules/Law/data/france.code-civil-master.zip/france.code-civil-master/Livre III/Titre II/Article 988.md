Article 988
----
Au cours d'un voyage maritime, soit en route, soit pendant un arrêt dans un
port, lorsqu'il y aura impossibilité de communiquer avec la terre ou lorsqu'il
n'existera pas dans le port, si l'on est à l'étranger, d'agent diplomatique ou
consulaire français investi des fonctions de notaire, les testaments des
personnes présentes à bord seront reçus, en présence de deux témoins : sur les
bâtiments de l'Etat, par l'officier d'administration ou, à son défaut, par le
commandant ou celui qui en remplit les fonctions, et sur les autres bâtiments,
par le capitaine, maître ou patron, assisté du second du navire, ou, à leur
défaut, par ceux qui les remplacent.

L'acte indiquera celle des circonstances ci-dessus prévues dans laquelle il aura
été reçu.
