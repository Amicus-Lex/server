Article 959
----
Les donations en faveur de mariage ne seront pas révocables pour cause
d'ingratitude.
