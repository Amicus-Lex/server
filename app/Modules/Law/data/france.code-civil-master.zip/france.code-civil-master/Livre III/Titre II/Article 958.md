Article 958
----
La révocation pour cause d'ingratitude ne préjudiciera ni aux aliénations faites
par le donataire, ni aux hypothèques et autres charges réelles qu'il aura pu
imposer sur l'objet de la donation, pourvu que le tout soit antérieur à la
publication, au fichier immobilier, de la demande en révocation.

Dans le cas de révocation, le donataire sera condamné à restituer la valeur des
objets aliénés, eu égard au temps de la demande, et les fruits, à compter du
jour de cette demande.
