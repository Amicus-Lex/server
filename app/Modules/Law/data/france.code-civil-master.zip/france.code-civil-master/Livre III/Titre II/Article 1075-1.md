Article 1075-1
----
Toute personne peut également faire la distribution et le partage de ses biens
et de ses droits entre des descendants de degrés différents, qu'ils soient ou
non ses héritiers présomptifs.
