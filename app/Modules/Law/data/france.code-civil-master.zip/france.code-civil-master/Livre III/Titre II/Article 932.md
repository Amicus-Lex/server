Article 932
----
La donation entre vifs n'engagera le donateur, et ne produira aucun effet, que
du jour qu'elle aura été acceptée en termes exprès.

L'acceptation pourra être faite du vivant du donateur par un acte postérieur et
authentique, dont il restera minute ; mais alors la donation n'aura d'effet, à
l'égard du donateur, que du jour où l'acte qui constatera cette acceptation lui
aura été notifié.
