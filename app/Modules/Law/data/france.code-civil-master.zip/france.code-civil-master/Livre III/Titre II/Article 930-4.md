Article 930-4
----
La révocation n'a jamais lieu de plein droit.

La demande en révocation est formée dans l'année, à compter du jour de
l'ouverture de la succession, si elle est fondée sur l'état de besoin. Elle est
formée dans l'année, à compter du jour du fait imputé par le renonçant ou du
jour où le fait a pu être connu par ses héritiers, si elle est fondée sur le
manquement aux obligations alimentaires ou sur l'un des faits visés au 3° de
l'article 930-3.

La révocation en application du 2° de l'article 930-3 n'est prononcée qu'à
concurrence des besoins de celui qui avait renoncé.
