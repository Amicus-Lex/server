Article 914-1
----
Les libéralités, par actes entre vifs ou par testament, ne pourront excéder les
trois quarts des biens si, à défaut de descendant, le défunt laisse un conjoint
survivant, non divorcé.
