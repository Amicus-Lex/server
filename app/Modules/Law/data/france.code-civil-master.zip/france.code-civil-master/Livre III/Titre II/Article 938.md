Article 938
----
La donation dûment acceptée sera parfaite par le seul consentement des parties ;
et la propriété des objets donnés sera transférée au donataire, sans qu'il soit
besoin d'autre tradition.
