Article 924-2
----
Le montant de l'indemnité de réduction se calcule d'après la valeur des biens
donnés ou légués à l'époque du partage ou de leur aliénation par le gratifié et
en fonction de leur état au jour où la libéralité a pris effet. S'il y a eu
subrogation, le calcul de l'indemnité de réduction tient compte de la valeur des
nouveaux biens à l'époque du partage, d'après leur état à l'époque de
l'acquisition. Toutefois, si la dépréciation des nouveaux biens était, en raison
de leur nature, inéluctable au jour de leur acquisition, il n'est pas tenu
compte de la subrogation.
