Article 930-1
----
La capacité requise du renonçant est celle exigée pour consentir une donation
entre vifs. Toutefois, le mineur émancipé ne peut renoncer par anticipation à
l'action en réduction.

La renonciation, quelles que soient ses modalités, ne constitue pas une
libéralité.
