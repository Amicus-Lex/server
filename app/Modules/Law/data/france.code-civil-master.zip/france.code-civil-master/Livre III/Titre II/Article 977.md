Article 977
----
Si le testateur ne sait signer ou s'il n'a pu le faire lorsqu'il a fait écrire
ses dispositions, il sera procédé comme il est dit à l'article précédent ; il
sera fait, en outre, mention à l'acte de suscription que le testateur a déclaré
ne savoir signer ou n'avoir pu le faire lorsqu'il a fait écrire ses
dispositions.
