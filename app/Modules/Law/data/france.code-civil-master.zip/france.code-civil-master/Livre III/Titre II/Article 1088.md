Article 1088
----
Toute donation faite en faveur du mariage sera caduque si le mariage ne s'ensuit
pas.
