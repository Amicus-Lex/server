Article 1030-1
----
En l'absence d'héritier réservataire acceptant, le testateur peut habiliter
l'exécuteur testamentaire à disposer en tout ou partie des immeubles de la
succession, recevoir et placer les capitaux, payer les dettes et les charges et
procéder à l'attribution ou au partage des biens subsistants entre les héritiers
et les légataires.

A peine d'inopposabilité, la vente d'un immeuble de la succession ne peut
intervenir qu'après information des héritiers par l'exécuteur testamentaire.
