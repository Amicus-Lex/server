Article 1080
----
Le bénéficiaire qui n'a pas reçu un lot égal à sa part de réserve peut exercer
l'action en réduction conformément à l'article 1077-2.
