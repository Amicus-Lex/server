Article 1091
----
Les époux pourront, par contrat de mariage, se faire réciproquement, ou l'un des
deux à l'autre, telle donation qu'ils jugeront à propos, sous les modifications
ci-après exprimées.
