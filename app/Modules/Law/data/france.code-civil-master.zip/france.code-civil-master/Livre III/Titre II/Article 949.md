Article 949
----
Il est permis au donateur de faire la réserve à son profit ou de disposer, au
profit d'un autre, de la jouissance ou de l'usufruit des biens meubles ou
immeubles donnés.
