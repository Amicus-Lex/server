Article 1048
----
Une libéralité peut être grevée d'une charge comportant l'obligation pour le
donataire ou le légataire de conserver les biens ou droits qui en sont l'objet
et de les transmettre, à son décès, à un second gratifié, désigné dans l'acte.
