Article 965
----
Le donateur peut, à tout moment, renoncer à exercer la révocation pour
survenance d'enfant.
