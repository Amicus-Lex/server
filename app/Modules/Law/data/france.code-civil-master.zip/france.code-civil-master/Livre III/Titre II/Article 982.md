Article 982
----
Les testaments mentionnés à l'article précédent pourront encore, si le testateur
est malade ou blessé, être reçus, dans les hôpitaux ou les formations sanitaires
militaires, telles que les définissent les règlements de l'armée, par le
médecin-chef, quel que soit son grade, assisté de l'officier d'administration
gestionnaire.

A défaut de cet officier d'administration, la présence de deux témoins sera
nécessaire.
