Article 1020
----
Si, avant le testament ou depuis, la chose léguée a été hypothéquée pour une
dette de la succession, ou même pour la dette d'un tiers, ou si elle est grevée
d'un usufruit, celui qui doit acquitter le legs n'est point tenu de la dégager,
à moins qu'il n'ait été chargé de le faire par une disposition expresse du
testateur.
