Article 986
----
Les testaments faits dans une île du territoire français, où il n'existe pas
d'office notarial, peuvent, lorsque toute communication avec le territoire
auquel cette île est rattachée est impossible, être reçus dans les formes
prévues à l'article 985. L'impossibilité des communications est attestée dans
l'acte par le juge d'instance ou l'officier municipal qui reçoit le testament.
