Article 930-2
----
La renonciation ne produit aucun effet s'il n'a pas été porté atteinte à la
réserve héréditaire du renonçant. Si l'atteinte à la réserve héréditaire n'a été
exercée que partiellement, la renonciation ne produit d'effets qu'à hauteur de
l'atteinte à la réserve du renonçant résultant de la libéralité consentie. Si
l'atteinte à la réserve porte sur une fraction supérieure à celle prévue dans la
renonciation, l'excédent est sujet à réduction.

La renonciation relative à la réduction d'une libéralité portant sur un bien
déterminé est caduque si la libéralité attentatoire à la réserve ne porte pas
sur ce bien. Il en va de même si la libéralité n'a pas été faite au profit de la
ou des personnes déterminées.
