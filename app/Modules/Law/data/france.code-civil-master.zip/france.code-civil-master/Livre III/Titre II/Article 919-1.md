Article 919-1
----
La donation faite en avancement de part successorale à un héritier réservataire
qui accepte la succession s'impute sur sa part de réserve et, subsidiairement,
sur la quotité disponible, s'il n'en a pas été autrement convenu dans l'acte de
donation.L'excédent est sujet à réduction.

La donation faite en avancement de part successorale à un héritier réservataire
qui renonce à la succession est traitée comme une donation faite hors part
successorale. Toutefois, lorsqu'il est astreint au rapport en application des
dispositions de l'article 845, l'héritier qui renonce est traité comme un
héritier acceptant pour la réunion fictive l'imputation et, le cas échéant, la
réduction de la libéralité qui lui a été consentie.
