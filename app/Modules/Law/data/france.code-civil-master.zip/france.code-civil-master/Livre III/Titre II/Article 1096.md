Article 1096
----
La donation de biens à venir faite entre époux pendant le mariage est toujours
révocable.

La donation de biens présents qui prend effet au cours du mariage faite entre
époux n'est révocable que dans les conditions prévues par les articles 953 à
958.

Les donations faites entre époux de biens présents ou de biens à venir ne sont
pas révoquées par la survenance d'enfants.
