Article 1099-1
----
Quand un époux acquiert un bien avec des deniers qui lui ont été donnés par
l'autre à cette fin, la donation n'est que des deniers et non du bien auquel ils
sont employés.

En ce cas, les droits du donateur ou de ses héritiers n'ont pour objet qu'une
somme d'argent suivant la valeur actuelle du bien. Si le bien a été aliéné, on
considère la valeur qu'il avait au jour de l'aliénation, et si un nouveau bien a
été subrogé au bien aliéné, la valeur de ce nouveau bien.
