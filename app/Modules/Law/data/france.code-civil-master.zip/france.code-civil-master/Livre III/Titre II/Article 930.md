Article 930
----
La renonciation est établie par acte authentique spécifique reçu par deux
notaires. Elle est signée séparément par chaque renonçant en présence des seuls
notaires. Elle mentionne précisément ses conséquences juridiques futures pour
chaque renonçant.

La renonciation est nulle lorsqu'elle n'a pas été établie dans les conditions
fixées au précédent alinéa, ou lorsque le consentement du renonçant a été vicié
par l'erreur, le dol ou la violence.

La renonciation peut être faite dans le même acte par plusieurs héritiers
réservataires.
