Article 1013
----
Lorsque le testateur n'aura disposé que d'une quotité de la portion disponible,
et qu'il l'aura fait à titre universel, ce légataire sera tenu d'acquitter les
legs particuliers par contribution avec les héritiers naturels.
