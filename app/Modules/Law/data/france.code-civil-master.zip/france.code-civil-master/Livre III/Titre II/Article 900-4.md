Article 900-4
----
Le juge saisi de la demande en révision peut, selon les cas et même d'office,
soit réduire en quantité ou périodicité les prestations grevant la libéralité,
soit en modifier l'objet en s'inspirant de l'intention du disposant, soit même
les regrouper, avec des prestations analogues résultant d'autres libéralités.

Il peut autoriser l'aliénation de tout ou partie des biens faisant l'objet de la
libéralité en ordonnant que le prix en sera employé à des fins en rapport avec
la volonté du disposant.

Il prescrit les mesures propres à maintenir, autant qu'il est possible,
l'appellation que le disposant avait entendu donner à sa libéralité.
