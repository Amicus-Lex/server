Article 1076-1
----
En cas de donation-partage faite conjointement par deux époux, l'enfant non
commun peut être alloti du chef de son auteur en biens propres de celui-ci ou en
biens communs, sans que le conjoint puisse toutefois être codonateur des biens
communs.
