Article 1027
----
S'il y a plusieurs exécuteurs testamentaires acceptant, l'un d'eux peut agir à
défaut des autres, à moins que le testateur en ait disposé autrement ou qu'il
ait divisé leur fonction.
