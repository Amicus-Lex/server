Article 1078-1
----
Le lot de certains gratifiés pourra être formé, en totalité ou en partie, des
donations, soit rapportables, soit faites hors part, déjà reçues par eux du
disposant, eu égard éventuellement aux emplois et remplois qu'ils auront pu
faire dans l'intervalle.

La date d'évaluation applicable au partage anticipé sera également applicable
aux donations antérieures qui lui auront été ainsi incorporées. Toute
stipulation contraire sera réputée non écrite.
