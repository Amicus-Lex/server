Article 1078-6
----
Lorsque des descendants de degrés différents concourent à la même donation-
partage, le partage s'opère par souche.

Des attributions peuvent être faites à des descendants de degrés différents dans
certaines souches et non dans d'autres.
