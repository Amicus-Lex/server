Article 900-6
----
La tierce opposition à l'encontre du jugement faisant droit à la demande en
révision n'est recevable qu'en cas de fraude imputable au donataire ou
légataire.

La rétractation ou la réformation du jugement attaqué n'ouvre droit à aucune
action contre le tiers acquéreur de bonne foi.
