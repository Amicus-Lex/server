Article 894
----
La donation entre vifs est un acte par lequel le donateur se dépouille
actuellement et irrévocablement de la chose donnée en faveur du donataire qui
l'accepte.
