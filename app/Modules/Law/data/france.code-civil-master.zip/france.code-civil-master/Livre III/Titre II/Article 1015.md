Article 1015
----
Les intérêts ou fruits de la chose léguée courront au profit du légataire, dès
le jour du décès, et sans qu'il ait formé sa demande en justice :

1° Lorsque le testateur aura expressément déclaré sa volonté, à cet égard, dans
le testament ;

2° Lorsqu'une rente viagère ou une pension aura été léguée à titre d'aliments.
