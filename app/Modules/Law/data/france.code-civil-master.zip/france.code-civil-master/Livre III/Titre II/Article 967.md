Article 967
----
Toute personne pourra disposer par testament soit sous le titre d'institution
d'héritier, soit sous le titre de legs, soit sous toute autre dénomination
propre à manifester sa volonté.
