Article 1077
----
Les biens reçus à titre de partage anticipé par un héritier réservataire
présomptif s'imputent sur sa part de réserve, à moins qu'ils n'aient été donnés
expressément hors part.
