Article 909
----
Les membres des professions médicales et de la pharmacie, ainsi que les
auxiliaires médicaux qui ont prodigué des soins à une personne pendant la
maladie dont elle meurt ne peuvent profiter des dispositions entre vifs ou
testamentaires qu'elle aurait faites en leur faveur pendant le cours de celle-
ci.

Les mandataires judiciaires à la protection des majeurs et les personnes morales
au nom desquelles ils exercent leurs fonctions ne peuvent pareillement profiter
des dispositions entre vifs ou testamentaires que les personnes dont ils
assurent la protection auraient faites en leur faveur quelle que soit la date de
la libéralité.

Sont exceptées :

1° Les dispositions rémunératoires faites à titre particulier, eu égard aux
facultés du disposant et aux services rendus ;

2° Les dispositions universelles, dans le cas de parenté jusqu'au quatrième
degré inclusivement, pourvu toutefois que le décédé n'ait pas d'héritiers en
ligne directe ; à moins que celui au profit de qui la disposition a été faite ne
soit lui-même du nombre de ces héritiers.

Les mêmes règles seront observées à l'égard du ministre du culte.
