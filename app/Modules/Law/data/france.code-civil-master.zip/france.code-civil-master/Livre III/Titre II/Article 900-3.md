Article 900-3
----
La demande en révision est formée par voie principale ; elle peut l'être aussi
par voie reconventionnelle, en réponse à l'action en exécution ou en révocation
que les héritiers du disposant ont introduite.

Elle est formée contre les héritiers ; elle l'est en même temps contre le
ministère public s'il y a doute sur l'existence ou l'identité de certains
d'entre eux ; s'il n'y a pas d'héritier connu, elle est formée contre le
ministère public.

Celui-ci doit, dans tous les cas, avoir communication de l'affaire.
