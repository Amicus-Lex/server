Article 956
----
La révocation pour cause d'inexécution des conditions, ou pour cause
d'ingratitude, n'aura jamais lieu de plein droit.
