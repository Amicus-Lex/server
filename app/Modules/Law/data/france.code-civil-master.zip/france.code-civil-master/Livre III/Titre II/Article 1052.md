Article 1052
----
Il appartient au disposant de prescrire des garanties et des sûretés pour la
bonne exécution de la charge.
