Article 1053
----
Le second gratifié ne peut être soumis à l'obligation de conserver et de
transmettre.

Si la charge a été stipulée au-delà du premier degré, elle demeure valable mais
pour le premier degré seulement.
