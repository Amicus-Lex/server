Article 900
----
Dans toute disposition entre vifs ou testamentaire, les conditions impossibles,
celles qui sont contraires aux lois ou aux moeurs, seront réputées non écrites.
