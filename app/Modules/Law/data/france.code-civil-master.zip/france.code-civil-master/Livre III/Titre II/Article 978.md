Article 978
----
Ceux qui ne savent ou ne peuvent lire ne pourront faire de dispositions dans la
forme du testament mystique.
