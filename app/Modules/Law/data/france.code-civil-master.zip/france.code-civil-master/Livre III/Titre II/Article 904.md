Article 904
----
Le mineur, parvenu à l'âge de seize ans et non émancipé, ne pourra disposer que
par testament, et jusqu'à concurrence seulement de la moitié des biens dont la
loi permet au majeur de disposer.

Toutefois, s'il est appelé sous les drapeaux pour une campagne de guerre, il
pourra, pendant la durée des hostilités, disposer de la même quotité que s'il
était majeur, en faveur de l'un quelconque de ses parents ou de plusieurs
d'entre eux et jusqu'au sixième degré inclusivement ou encore en faveur de son
conjoint survivant.

A défaut de parents au sixième degré inclusivement, le mineur pourra disposer
comme le ferait un majeur.
