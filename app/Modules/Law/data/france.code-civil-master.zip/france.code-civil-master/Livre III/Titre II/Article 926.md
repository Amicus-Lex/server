Article 926
----
Lorsque les dispositions testamentaires excéderont soit la quotité disponible,
soit la portion de cette quotité qui resterait après avoir déduit la valeur des
donations entre vifs, la réduction sera faite au marc le franc, sans aucune
distinction entre les legs universels et les legs particuliers.
