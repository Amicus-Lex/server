Article 1086
----
La donation par contrat de mariage en faveur des époux et des enfants à naître
de leur mariage pourra encore être faite, à condition de payer indistinctement
toutes les dettes et charges de la succession du donateur, ou sous d'autres
conditions dont l'exécution dépendrait de sa volonté, par quelque personne que
la donation soit faite : le donataire sera tenu d'accomplir ces conditions, s'il
n'aime mieux renoncer à la donation ; et en cas que le donateur, par contrat de
mariage, se soit réservé la liberté de disposer d'un effet compris dans la
donation de ses biens présents, ou d'une somme fixe à prendre sur ces mêmes
biens, l'effet ou la somme, s'il meurt sans en avoir disposé, seront censés
compris dans la donation et appartiendront au donataire ou à ses héritiers.
