Article 971
----
Le testament par acte public est reçu par deux notaires ou par un notaire
assisté de deux témoins.
