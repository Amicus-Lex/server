Article 997
----
Les testaments compris dans les articles ci-dessus de la présente section seront
signés par le testateur, par ceux qui les auront reçus et par les témoins.
