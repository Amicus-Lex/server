Article 1082
----
Les père et mère, les autres ascendants, les parents collatéraux des époux, et
même les étrangers, pourront, par contrat de mariage, disposer de tout ou partie
des biens qu'ils laisseront au jour de leur décès, tant au profit desdits époux,
qu'au profit des enfants à naître de leur mariage, dans le cas où le donateur
survivrait à l'époux donataire.

Pareille donation, quoique faite au profit seulement des époux ou de l'un d'eux,
sera toujours, dans ledit cas de survie du donateur, présumée faite au profit
des enfants et descendants à naître du mariage.
