Article 1037
----
La révocation faite dans un testament postérieur aura tout son effet, quoique ce
nouvel acte reste sans exécution par l'incapacité de l'héritier institué ou du
légataire, ou par leur refus de recueillir.
