Article 917
----
Si la disposition par acte entre vifs ou par testament est d'un usufruit ou
d'une rente viagère dont la valeur excède la quotité disponible, les héritiers
au profit desquels la loi fait une réserve, auront l'option, ou d'exécuter cette
disposition, ou de faire l'abandon de la propriété de la quotité disponible.
