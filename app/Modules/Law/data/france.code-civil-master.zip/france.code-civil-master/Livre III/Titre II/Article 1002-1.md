Article 1002-1
----
Sauf volonté contraire du disposant, lorsque la succession a été acceptée par au
moins un héritier désigné par la loi, le légataire peut cantonner son émolument
sur une partie des biens dont il a été disposé en sa faveur. Ce cantonnement ne
constitue pas une libéralité faite par le légataire aux autres successibles.
