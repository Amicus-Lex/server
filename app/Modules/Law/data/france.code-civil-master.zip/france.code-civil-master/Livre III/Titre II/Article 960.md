Article 960
----
Toutes donations entre vifs faites par personnes qui n'avaient point d'enfants
ou de descendants actuellement vivants dans le temps de la donation, de quelque
valeur que ces donations puissent être, et à quelque titre qu'elles aient été
faites, et encore qu'elles fussent mutuelles ou rémunératoires, même celles qui
auraient été faites en faveur de mariage par autres que par les conjoints l'un à
l'autre, peuvent être révoquées, si l'acte de donation le prévoit, par la
survenance d'un enfant issu du donateur, même après son décès, ou adopté par lui
dans les formes et conditions prévues au chapitre Ier du titre VIII du livre
Ier.
