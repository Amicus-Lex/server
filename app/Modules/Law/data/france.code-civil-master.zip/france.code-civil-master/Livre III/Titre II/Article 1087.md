Article 1087
----
Les donations faites par contrat de mariage ne pourront être attaquées ni
déclarées nulles sous prétexte de défaut d'acceptation.
