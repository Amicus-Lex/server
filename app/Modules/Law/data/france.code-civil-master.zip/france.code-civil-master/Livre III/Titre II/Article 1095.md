Article 1095
----
Le mineur ne pourra, par contrat de mariage, donner à l'autre époux, soit par
donation simple, soit par donation réciproque, qu'avec le consentement et
l'assistance de ceux dont le consentement est requis pour la validité de son
mariage ; et, avec ce consentement, il pourra donner tout ce que la loi permet à
l'époux majeur de donner à l'autre conjoint.
