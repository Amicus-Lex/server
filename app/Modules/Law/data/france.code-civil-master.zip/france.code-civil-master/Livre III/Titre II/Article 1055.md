Article 1055
----
L'auteur d'une donation graduelle peut la révoquer à l'égard du second gratifié
tant que celui-ci n'a pas notifié, dans les formes requises en matière de
donation, son acceptation au donateur.

Par dérogation à l'article 932, la donation graduelle peut être acceptée par le
second gratifié après le décès du donateur.
