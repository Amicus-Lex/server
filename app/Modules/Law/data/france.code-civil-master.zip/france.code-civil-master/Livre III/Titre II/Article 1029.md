Article 1029
----
L'exécuteur testamentaire prend les mesures conservatoires utiles à la bonne
exécution du testament.

Il peut faire procéder, dans les formes prévues à l'article 789, à l'inventaire
de la succession en présence ou non des héritiers, après les avoir dûment
appelés.

Il peut provoquer la vente du mobilier à défaut de liquidités suffisantes pour
acquitter les dettes urgentes de la succession.
