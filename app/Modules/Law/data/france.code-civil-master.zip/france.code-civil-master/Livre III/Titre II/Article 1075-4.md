Article 1075-4
----
Les dispositions de l'article 828, sont applicables aux soultes mises à la
charge des donataires, nonobstant toute convention contraire.
