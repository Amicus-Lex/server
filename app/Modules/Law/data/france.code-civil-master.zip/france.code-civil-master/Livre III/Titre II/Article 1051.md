Article 1051
----
Le second gratifié est réputé tenir ses droits de l'auteur de la libéralité. Il
en va de même de ses héritiers lorsque ceux-ci recueillent la libéralité dans
les conditions prévues à l'article 1056.
