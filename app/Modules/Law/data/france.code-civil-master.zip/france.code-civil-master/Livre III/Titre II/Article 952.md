Article 952
----
L'effet du droit de retour est de résoudre toutes les aliénations des biens et
des droits donnés, et de faire revenir ces biens et droits au donateur, libres
de toutes charges et hypothèques, exceptée l'hypothèque légale des époux si les
autres biens de l'époux donataire ne suffisent pas à l'accomplissement de ce
retour et que la donation lui a été faite par le contrat de mariage dont
résultent ces charges et hypothèques.
