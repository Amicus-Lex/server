Article 944
----
Toute donation entre vifs, faite sous des conditions dont l'exécution dépend de
la seule volonté du donateur, sera nulle.
