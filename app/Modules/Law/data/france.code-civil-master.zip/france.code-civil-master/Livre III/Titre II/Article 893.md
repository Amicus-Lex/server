Article 893
----
La libéralité est l'acte par lequel une personne dispose à titre gratuit de tout
ou partie de ses biens ou de ses droits au profit d'une autre personne.

Il ne peut être fait de libéralité que par donation entre vifs ou par testament.
