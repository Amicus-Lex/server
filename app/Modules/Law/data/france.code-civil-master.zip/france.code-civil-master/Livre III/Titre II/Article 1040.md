Article 1040
----
Toute disposition testamentaire faite sous une condition dépendante d'un
événement incertain, et telle que, dans l'intention du testateur, cette
disposition ne doive être exécutée qu'autant que l'événement arrivera ou
n'arrivera pas, sera caduque, si l'héritier institué ou le légataire décède
avant l'accomplissement de la condition.
