Article 1059
----
Le premier gratifié ne peut disposer par testament des biens donnés ou légués à
titre résiduel.

La libéralité résiduelle peut interdire au premier gratifié de disposer des
biens par donation entre vifs.

Toutefois, lorsqu'il est héritier réservataire, le premier gratifié conserve la
possibilité de disposer entre vifs ou à cause de mort des biens qui ont été
donnés en avancement de part successorale.
