Article 992
----
A l'arrivée du bâtiment dans un port du territoire national, les deux originaux
du testament, ou l'original et son expédition, ou l'original qui reste, en cas
de transmission ou de remise effectuée pendant le cours du voyage, sont déposés,
sous pli clos et cacheté, pour les bâtiments de l'Etat au ministre chargé de la
défense nationale et, pour les autres bâtiments, au ministre chargé de la mer.
Chacune de ces pièces est adressée, séparément et par courriers différents, au
ministre chargé de la mer, qui les transmet conformément à l'article 983.
