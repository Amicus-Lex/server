Article 916
----
A défaut de descendant et de conjoint survivant non divorcé, les libéralités par
actes entre vifs ou testamentaires pourront épuiser la totalité des biens.
