Article 1083
----
La donation dans la forme portée au précédent article sera irrévocable en ce
sens seulement que le donateur ne pourra plus disposer, à titre gratuit, des
objets compris dans la donation, si ce n'est pour sommes modiques, à titre de
récompense ou autrement.
