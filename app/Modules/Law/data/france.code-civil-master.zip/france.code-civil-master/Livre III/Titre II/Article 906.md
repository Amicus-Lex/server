Article 906
----
Pour être capable de recevoir entre vifs, il suffit d'être conçu au moment de la
donation.

Pour être capable de recevoir par testament, il suffit d'être conçu à l'époque
du décès du testateur.

Néanmoins, la donation ou le testament n'auront leur effet qu'autant que
l'enfant sera né viable.
