Article 1033-1
----
La mission d'exécuteur testamentaire est gratuite, sauf libéralité faite à titre
particulier eu égard aux facultés du disposant et aux services rendus.
