Article 1089
----
Les donations faites à l'un des époux, dans les termes des articles 1082, 1084
et 1086 ci-dessus, deviendront caduques si le donateur survit à l'époux
donataire et à sa postérité.
