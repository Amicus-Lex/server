Article 900-7
----
Si, postérieurement à la révision, l'exécution des conditions ou des charges,
telle qu'elle était prévue à l'origine, redevient possible, elle pourra être
demandée par les héritiers.
