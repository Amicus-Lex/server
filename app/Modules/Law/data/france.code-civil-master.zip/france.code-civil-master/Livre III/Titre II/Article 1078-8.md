Article 1078-8
----
Dans la succession de l'ascendant donateur, les biens reçus par les enfants ou
leurs descendants à titre de partage anticipé s'imputent sur la part de réserve
revenant à leur souche et subsidiairement sur la quotité disponible.

Toutes les donations faites aux membres d'une même souche sont imputées
ensemble, quel que soit le degré de parenté avec le défunt.

Lorsque tous les enfants de l'ascendant donateur ont donné leur consentement au
partage anticipé et qu'il n'a pas été prévu de réserve d'usufruit portant sur
une somme d'argent, les biens dont les gratifiés ont été allotis sont évalués
selon la règle prévue à l'article 1078.

Si les descendants d'une souche n'ont pas reçu de lot dans la donation-partage
ou n'y ont reçu qu'un lot inférieur à leur part de réserve, ils sont remplis de
leurs droits selon les règles prévues par les articles 1077-1 et 1077-2.
