Article 955
----
La donation entre vifs ne pourra être révoquée pour cause d'ingratitude que dans
les cas suivants :

1° Si le donataire a attenté à la vie du donateur ;

2° S'il s'est rendu coupable envers lui de sévices, délits ou injures graves ;

3° S'il lui refuse des aliments.
