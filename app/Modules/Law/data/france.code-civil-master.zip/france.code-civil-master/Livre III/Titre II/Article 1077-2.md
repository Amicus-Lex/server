Article 1077-2
----
Les donations-partages suivent les règles des donations entre vifs pour tout ce
qui concerne l'imputation, le calcul de la réserve et la réduction.

L'action en réduction ne peut être introduite qu'après le décès du disposant qui
a fait le partage. En cas de donation-partage faite conjointement par les deux
époux, l'action en réduction ne peut être introduite qu'après le décès du
survivant des disposants, sauf pour l'enfant non commun qui peut agir dès le
décès de son auteur. L'action se prescrit par cinq ans à compter de ce décès.

L'héritier présomptif non encore conçu au moment de la donation-partage dispose
d'une semblable action pour composer ou compléter sa part héréditaire.
