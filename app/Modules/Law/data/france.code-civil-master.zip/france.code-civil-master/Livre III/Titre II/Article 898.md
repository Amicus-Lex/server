Article 898
----
La disposition par laquelle un tiers serait appelé à recueillir le don, la
succession ou le legs, dans le cas où le donataire, l'héritier institué ou le
légataire ne le recueillerait pas, ne sera pas regardée comme une substitution
et sera valable.
