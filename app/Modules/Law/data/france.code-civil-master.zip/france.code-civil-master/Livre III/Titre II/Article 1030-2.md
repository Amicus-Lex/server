Article 1030-2
----
Lorsque le testament a revêtu la forme authentique, l'envoi en possession prévu
à l'article 1008 n'est pas requis pour l'exécution des pouvoirs mentionnés aux
articles 1030 et 1030-1.
