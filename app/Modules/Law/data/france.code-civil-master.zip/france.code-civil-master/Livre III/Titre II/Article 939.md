Article 939
----
Lorsqu'il y aura donation de biens susceptibles d'hypothèques, la publication
des actes contenant la donation et l'acceptation, ainsi que la notification de
l'acceptation qui aurait eu lieu par acte séparé, devra être faite au service
chargé de la publicité foncière de la situation des biens.
