Article 1078-9
----
Dans la succession de l'enfant qui a consenti à ce que ses propres descendants
soient allotis en son lieu et place, les biens reçus par eux de l'ascendant sont
traités comme s'ils les tenaient de leur auteur direct.

Ces biens sont soumis aux règles dont relèvent les donations entre vifs pour la
réunion fictive, l'imputation, le rapport et, le cas échéant, la réduction.

Toutefois, lorsque tous les descendants ont reçu et accepté un lot dans le
partage anticipé et qu'il n'a pas été prévu d'usufruit portant sur une somme
d'argent, les biens dont ont été allotis les gratifiés sont traités comme s'ils
les avaient reçus de leur auteur par donation-partage.
