Article 1078-4
----
Lorsque l'ascendant procède à une donation-partage, ses enfants peuvent
consentir à ce que leurs propres descendants y soient allotis en leur lieu et
place, en tout ou partie.

Les descendants d'un degré subséquent peuvent, dans le partage anticipé, être
allotis séparément ou conjointement entre eux.
