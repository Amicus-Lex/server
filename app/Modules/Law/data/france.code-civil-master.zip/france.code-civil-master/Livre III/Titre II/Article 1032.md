Article 1032
----
La mission de l'exécuteur testamentaire prend fin au plus tard deux ans après
l'ouverture du testament sauf prorogation par le juge.
