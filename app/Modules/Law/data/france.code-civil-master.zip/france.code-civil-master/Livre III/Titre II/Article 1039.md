Article 1039
----
Toute disposition testamentaire sera caduque si celui en faveur de qui elle est
faite n'a pas survécu au testateur.
