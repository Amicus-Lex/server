Article 993
----
Le rôle du bâtiment mentionne, en regard du nom du testateur, la remise des
originaux ou l'expédition du testament faite, selon le cas, au consulat, au
ministre chargé de la défense nationale ou au ministre chargé de la mer.
