Article 1030
----
Le testateur peut habiliter l'exécuteur testamentaire à prendre possession en
tout ou partie du mobilier de la succession et à le vendre s'il est nécessaire
pour acquitter les legs particuliers dans la limite de la quotité disponible.
