Article 1077-1
----
L'héritier réservataire, qui n'a pas concouru à la donation-partage, ou qui a
reçu un lot inférieur à sa part de réserve, peut exercer l'action en réduction,
s'il n'existe pas à l'ouverture de la succession des biens non compris dans le
partage et suffisants pour composer ou compléter sa réserve, compte tenu des
libéralités dont il a pu bénéficier.
