Article 945
----
Elle sera pareillement nulle si elle a été faite sous la condition d'acquitter
d'autres dettes ou charges que celles qui existaient à l'époque de la donation
ou qui seraient exprimées soit dans l'acte de donation, soit dans l'état qui
devrait y être annexé.
