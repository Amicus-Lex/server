Article 1085
----
Si l'état dont est mention au précédent article n'a point été annexé à l'acte
contenant donation des biens présents et à venir, le donataire sera obligé
d'accepter ou de répudier cette donation pour le tout. En cas d'acceptation, il
ne pourra réclamer que les biens qui se trouveront existants au jour du décès du
donateur, et il sera soumis au paiement de toutes les dettes et charges de la
succession.
