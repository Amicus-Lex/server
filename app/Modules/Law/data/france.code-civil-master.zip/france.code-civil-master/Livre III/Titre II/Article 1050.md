Article 1050
----
Les droits du second gratifié s'ouvrent à la mort du grevé.

Toutefois, le grevé peut abandonner, au profit du second gratifié, la jouissance
du bien ou du droit objet de la libéralité.

Cet abandon anticipé ne peut préjudicier aux créanciers du grevé antérieurs à
l'abandon, ni aux tiers ayant acquis, de ce dernier, un droit sur le bien ou le
droit abandonné.
