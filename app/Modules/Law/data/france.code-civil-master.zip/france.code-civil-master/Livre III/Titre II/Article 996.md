Article 996
----
Il sera donné lecture au testateur, en présence des témoins, des dispositions de
l'article 984, 987 ou 994, suivant le cas, et mention de cette lecture sera
faite dans le testament.
