Article 1024
----
Le légataire à titre particulier ne sera point tenu des dettes de la succession,
sauf la réduction du legs ainsi qu'il est dit ci-dessus, et sauf l'action
hypothécaire des créanciers.
