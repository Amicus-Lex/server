Article 1003
----
Le legs universel est la disposition testamentaire par laquelle le testateur
donne à une ou plusieurs personnes l'universalité des biens qu'il laissera à son
décès.
