Article 1009
----
Le légataire universel, qui sera en concours avec un héritier auquel la loi
réserve une quotité des biens, sera tenu des dettes et charges de la succession
du testateur, personnellement pour sa part et portion et hypothécairement pour
le tout ; et il sera tenu d'acquitter tous les legs, sauf le cas de réduction,
ainsi qu'il est expliqué aux articles 926 et 927.
