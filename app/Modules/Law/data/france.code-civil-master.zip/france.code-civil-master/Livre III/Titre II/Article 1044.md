Article 1044
----
Il y aura lieu à accroissement au profit des légataires dans le cas où le legs
sera fait à plusieurs conjointement.

Le legs sera réputé fait conjointement lorsqu'il le sera par une seule et même
disposition et que le testateur n'aura pas assigné la part de chacun des
colégataires dans la chose léguée.
