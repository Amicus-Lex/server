Article 970
----
Le testament olographe ne sera point valable s'il n'est écrit en entier, daté et
signé de la main du testateur : il n'est assujetti à aucune autre forme.
