Article 919-2
----
La libéralité faite hors part successorale s'impute sur la quotité disponible.
L'excédent est sujet à réduction.
