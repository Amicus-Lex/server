Article 1057
----
Il peut être prévu dans une libéralité qu'une personne sera appelée à recueillir
ce qui subsistera du don ou legs fait à un premier gratifié à la mort de celui-
ci.
