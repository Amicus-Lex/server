Article 1022
----
Lorsque le legs sera d'une chose indéterminée, l'héritier ne sera pas obligé de
la donner de la meilleure qualité, et il ne pourra l'offrir de la plus mauvaise.
