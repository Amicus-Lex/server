Article 1047
----
Si cette demande est fondée sur une injure grave faite à la mémoire du
testateur, elle doit être intentée dans l'année, à compter du jour du délit.
