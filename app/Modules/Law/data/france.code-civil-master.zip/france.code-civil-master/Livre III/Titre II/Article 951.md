Article 951
----
Le donateur pourra stipuler le droit de retour des objets donnés soit pour le
cas du prédécès du donataire seul, soit pour le cas du prédécès du donataire et
de ses descendants.

Ce droit ne pourra être stipulé qu'au profit du donateur seul.
