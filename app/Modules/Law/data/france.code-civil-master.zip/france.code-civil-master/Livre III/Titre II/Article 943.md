Article 943
----
La donation entre vifs ne pourra comprendre que les biens présents du donateur ;
si elle comprend des biens à venir, elle sera nulle à cet égard.
