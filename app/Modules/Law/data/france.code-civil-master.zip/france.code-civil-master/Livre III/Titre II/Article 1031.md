Article 1031
----
Les habilitations mentionnées aux articles 1030 et 1030-1 sont données par le
testateur pour une durée qui ne peut excéder deux années à compter de
l'ouverture du testament. Une prorogation d'une année au plus peut être accordée
par le juge.
