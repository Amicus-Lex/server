Article 966
----
L'action en révocation se prescrit par cinq ans à compter de la naissance ou de
l'adoption du dernier enfant. Elle ne peut être exercée que par le donateur.
