Article 1094-1
----
Pour le cas où l'époux laisserait des enfants ou descendants, issus ou non du
mariage, il pourra disposer en faveur de l'autre époux, soit de la propriété de
ce dont il pourrait disposer en faveur d'un étranger, soit d'un quart de ses
biens en propriété et des trois autres quarts en usufruit, soit encore de la
totalité de ses biens en usufruit seulement.

Sauf stipulation contraire du disposant, le conjoint survivant peut cantonner
son émolument sur une partie des biens dont il a été disposé en sa faveur. Cette
limitation ne peut être considérée comme une libéralité faite aux autres
successibles.
