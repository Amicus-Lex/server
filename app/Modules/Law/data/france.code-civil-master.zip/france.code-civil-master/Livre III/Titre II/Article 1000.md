Article 1000
----
Les testaments faits en pays étranger ne pourront être exécutés sur les biens
situés en France qu'après avoir été enregistrés au bureau du domicile du
testateur, s'il en a conservé un, sinon au bureau de son dernier domicile connu
en France ; et, dans le cas où le testament contiendrait des dispositions
d'immeubles qui y seraient situés, il devra être, en outre, enregistré au bureau
de la situation de ces immeubles, sans qu'il puisse être exigé un double droit.
