Article 1028
----
L'exécuteur testamentaire est mis en cause en cas de contestation sur la
validité ou l'exécution d'un testament ou d'un legs.

Dans tous les cas, il intervient pour soutenir la validité ou exiger l'exécution
des dispositions litigieuses.
