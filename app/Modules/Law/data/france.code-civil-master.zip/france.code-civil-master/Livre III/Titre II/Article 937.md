Article 937
----
Sous réserve des dispositions des deuxième et troisième alinéas de l'article
910, les donations faites au profit d'établissements d'utilité publique sont
acceptées par les administrateurs de ces établissements, après y avoir été
dûment autorisés.
