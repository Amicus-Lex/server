Article 903
----
Le mineur âgé de moins de seize ans ne pourra aucunement disposer, sauf ce qui
est réglé au chapitre IX du présent titre.
