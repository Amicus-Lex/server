Article 1025
----
Le testateur peut nommer un ou plusieurs exécuteurs testamentaires jouissant de
la pleine capacité civile pour veiller ou procéder à l'exécution de ses
volontés.

L'exécuteur testamentaire qui a accepté sa mission est tenu de l'accomplir.

Les pouvoirs de l'exécuteur testamentaire ne sont pas transmissibles à cause de
mort.
