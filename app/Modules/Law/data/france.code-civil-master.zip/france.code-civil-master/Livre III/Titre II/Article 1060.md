Article 1060
----
Le premier gratifié n'est pas tenu de rendre compte de sa gestion au disposant
ou à ses héritiers.
