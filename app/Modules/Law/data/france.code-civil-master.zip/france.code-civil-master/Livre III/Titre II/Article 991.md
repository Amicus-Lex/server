Article 991
----
Au premier arrêt dans un port étranger où se trouve un agent diplomatique ou
consulaire français, l'un des originaux ou l'expédition du testament est remis,
sous pli clos et cacheté, à celui-ci. Cet agent adresse ce pli au ministre
chargé de la mer, afin que le dépôt prévu à l'article 983 soit effectué.
