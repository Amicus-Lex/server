Article 998
----
Si le testateur déclare qu'il ne peut ou ne sait signer, il sera fait mention de
sa déclaration, ainsi que de la cause qui l'empêche de signer.

Dans le cas où la présence de deux témoins est requise, le testament sera signé
au moins par l'un d'eux, et il sera fait mention de la cause pour laquelle
l'autre n'aura pas signé.
