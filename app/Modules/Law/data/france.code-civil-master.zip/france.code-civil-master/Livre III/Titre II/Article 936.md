Article 936
----
Le sourd-muet qui saura écrire pourra accepter lui-même ou par un fondé de
pouvoir.

S'il ne sait pas écrire, l'acceptation doit être faite par un curateur nommé à
cet effet, suivant les règles établies au titre De la minorité, de la tutelle et
de l'émancipation.
