Article 950
----
Lorsque la donation d'effets mobiliers aura été faite avec réserve d'usufruit,
le donataire sera tenu, à l'expiration de l'usufruit, de prendre les effets
donnés qui se trouveront en nature, dans l'état où il seront ; et il aura action
contre le donateur ou ses héritiers, pour raison des objets non existants,
jusqu'à concurrence de la valeur qui leur aura été donnée dans l'état estimatif.
