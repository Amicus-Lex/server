Article 1014
----
Tout legs pur et simple donnera au légataire, du jour du décès du testateur, un
droit à la chose léguée, droit transmissible à ses héritiers ou ayants cause.

Néanmoins le légataire particulier ne pourra se mettre en possession de la chose
léguée, ni en prétendre les fruits ou intérêts, qu'à compter du jour de sa
demande en délivrance, formée suivant l'ordre établi par l'article 1011, ou du
jour auquel cette délivrance lui aurait été volontairement consentie.
