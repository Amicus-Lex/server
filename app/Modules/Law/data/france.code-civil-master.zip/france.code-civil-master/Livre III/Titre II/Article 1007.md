Article 1007
----
Tout testament olographe ou mystique sera, avant d'être mis à exécution, déposé
entre les mains d'un notaire. Le testament sera ouvert s'il est cacheté. Le
notaire dressera sur-le-champ procès-verbal de l'ouverture et de l'état du
testament, en précisant les circonstances du dépôt. Le testament ainsi que le
procès-verbal seront conservés au rang des minutes du dépositaire.

Dans le mois qui suivra la date du procès-verbal, le notaire adressera une
expédition de celui-ci et une copie figurée du testament au greffier du tribunal
de grande instance du lieu d'ouverture de la succession, qui lui accusera
réception de ces documents et les conservera au rang de ses minutes.
