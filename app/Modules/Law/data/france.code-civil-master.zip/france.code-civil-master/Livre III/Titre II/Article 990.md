Article 990
----
Dans tous les cas, il sera fait un double original des testaments mentionnés aux
deux articles précédents.

Si cette formalité n'a pu être remplie à raison de l'état de santé du testateur,
il sera dressé une expédition du testament pour tenir lieu du second original ;
cette expédition sera signée par les témoins et par les officiers
instrumentaires. Il y sera fait mention des causes qui ont empêché de dresser le
second original.
