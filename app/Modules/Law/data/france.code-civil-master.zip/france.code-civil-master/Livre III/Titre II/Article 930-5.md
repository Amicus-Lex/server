Article 930-5
----
La renonciation est opposable aux représentants du renonçant.
