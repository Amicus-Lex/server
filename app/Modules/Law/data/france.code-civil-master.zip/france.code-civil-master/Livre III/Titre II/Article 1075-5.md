Article 1075-5
----
Si tous les biens ou droits que le disposant laisse au jour de son décès n'ont
pas été compris dans le partage, ceux de ses biens ou droits qui n'y ont pas été
compris sont attribués ou partagés conformément à la loi.
