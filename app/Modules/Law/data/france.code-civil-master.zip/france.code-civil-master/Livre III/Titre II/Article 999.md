Article 999
----
Un Français qui se trouvera en pays étranger pourra faire ses dispositions
testamentaires par acte sous signature privée, ainsi qu'il est prescrit en
l'article 970, ou par acte authentique, avec les formes usitées dans le lieu où
cet acte sera passé.
