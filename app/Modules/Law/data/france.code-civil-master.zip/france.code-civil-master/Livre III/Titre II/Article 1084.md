Article 1084
----
La donation par contrat de mariage pourra être faite cumulativement des biens
présents et à venir, en tout ou partie, à la charge qu'il sera annexé à l'acte
un état des dettes et charges du donateur existantes au jour de la donation ;
auquel cas, il sera libre au donataire, lors du décès du donateur, de s'en tenir
aux biens présents, en renonçant au surplus des biens du donateur.
