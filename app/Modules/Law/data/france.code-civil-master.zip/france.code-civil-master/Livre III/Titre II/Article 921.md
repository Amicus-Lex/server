Article 921
----
La réduction des dispositions entre vifs ne pourra être demandée que par ceux au
profit desquels la loi fait la réserve, par leurs héritiers ou ayants cause :
les donataires, les légataires, ni les créanciers du défunt ne pourront demander
cette réduction, ni en profiter.

Le délai de prescription de l'action en réduction est fixé à cinq ans à compter
de l'ouverture de la succession, ou à deux ans à compter du jour où les
héritiers ont eu connaissance de l'atteinte portée à leur réserve, sans jamais
pouvoir excéder dix ans à compter du décès.
