Article 948
----
Tout acte de donation d'effets mobiliers ne sera valable que pour les effets
dont un état estimatif, signé du donateur et du donataire, ou de ceux qui
acceptent pour lui, aura été annexé à la minute de la donation.
