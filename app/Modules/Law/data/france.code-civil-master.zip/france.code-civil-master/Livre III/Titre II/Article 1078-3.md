Article 1078-3
----
Les conventions dont il est parlé aux deux articles précédents peuvent avoir
lieu même en l'absence de nouvelles donations du disposant. Elles ne sont pas
regardées comme des libéralités entre les héritiers présomptifs, mais comme un
partage fait par le disposant.
