Article 902
----
Toutes personnes peuvent disposer et recevoir soit par donation entre vifs, soit
par testament, excepté celles que la loi en déclare incapables.
