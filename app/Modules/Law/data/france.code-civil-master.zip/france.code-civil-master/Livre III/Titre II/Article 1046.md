Article 1046
----
Les mêmes causes qui, suivant l'article 954 et les deux premières dispositions
de l'article 955, autoriseront la demande en révocation de la donation entre
vifs, seront admises pour la demande en révocation des dispositions
testamentaires.
