Article 924-4
----
Après discussion préalable des biens du débiteur de l'indemnité en réduction et
en cas d'insolvabilité de ce dernier, les héritiers réservataires peuvent
exercer l'action en réduction ou revendication contre les tiers détenteurs des
immeubles faisant partie des libéralités et aliénés par le gratifié.L'action est
exercée de la même manière que contre les gratifiés eux-mêmes et suivant l'ordre
des dates des aliénations, en commençant par la plus récente. Elle peut être
exercée contre les tiers détenteurs de meubles lorsque l'article 2276 ne peut
être invoqué.

Lorsque, au jour de la donation ou postérieurement, le donateur et tous les
héritiers réservataires présomptifs ont consenti à l'aliénation du bien donné,
aucun héritier réservataire, même né après que le consentement de tous les
héritiers intéressés a été recueilli, ne peut exercer l'action contre les tiers
détenteurs. S'agissant des biens légués, cette action ne peut plus être exercée
lorsque les héritiers réservataires ont consenti à l'aliénation.
