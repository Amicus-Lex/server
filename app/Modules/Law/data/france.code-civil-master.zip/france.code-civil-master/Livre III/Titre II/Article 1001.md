Article 1001
----
Les formalités auxquelles les divers testaments sont assujettis par les
dispositions de la présente section et de la précédente doivent être observées à
peine de nullité.
