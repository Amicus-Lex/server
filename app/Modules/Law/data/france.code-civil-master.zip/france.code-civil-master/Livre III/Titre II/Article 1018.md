Article 1018
----
La chose léguée sera délivrée avec les accessoires nécessaires et dans l'état où
elle se trouvera au jour du décès du donateur.
