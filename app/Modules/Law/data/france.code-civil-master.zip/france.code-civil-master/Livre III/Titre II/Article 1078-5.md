Article 1078-5
----
Cette libéralité constitue une donation-partage alors même que l'ascendant
donateur n'aurait qu'un enfant, que le partage se fasse entre celui-ci et ses
descendants ou entre ses descendants seulement.

Elle requiert le consentement, dans l'acte, de l'enfant qui renonce à tout ou
partie de ses droits, ainsi que de ses descendants qui en bénéficient. La
libéralité est nulle lorsque le consentement du renonçant a été vicié par
l'erreur, le dol ou la violence.
