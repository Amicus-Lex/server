Article 1008
----
Dans le cas de l'article 1006, si le testament est olographe ou mystique, le
légataire universel sera tenu de se faire envoyer en possession, par une
ordonnance du président, mise au bas d'une requête, à laquelle sera joint l'acte
de dépôt.
