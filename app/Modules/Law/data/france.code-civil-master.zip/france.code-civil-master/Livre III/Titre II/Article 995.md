Article 995
----
Les dispositions insérées dans un testament fait, au cours d'un voyage maritime,
au profit des officiers du bâtiment autres que ceux qui seraient parents ou
alliés du testateur, seront nulles et non avenues.

Il en sera ainsi, que le testament soit fait en la forme olographe ou qu'il soit
reçu conformément aux articles 988 et suivants.
