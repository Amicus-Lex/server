Article 919
----
La quotité disponible pourra être donnée en tout ou en partie soit par acte
entre vifs, soit par testament, aux enfants ou autres successibles du donateur,
sans être sujette au rapport par le donataire ou le légataire venant à la
succession, pourvu qu'en ce qui touche les dons la disposition ait été faite
expressément et hors part successorale.

La déclaration que la donation est hors part successorale pourra être faite,
soit par l'acte qui contiendra la disposition, soit postérieurement, dans la
forme des dispositions entre vifs ou testamentaires.
