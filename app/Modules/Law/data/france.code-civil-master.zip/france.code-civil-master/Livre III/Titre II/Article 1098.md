Article 1098
----
Si un époux a fait à son conjoint, dans les limites de l'article 1094-1, une
libéralité en propriété, chacun des enfants qui ne sont pas issus des deux époux
aura, en ce qui le concerne, sauf volonté contraire et non équivoque du
disposant, la faculté de substituer à l'exécution de cette libéralité l'abandon
de l'usufruit de la part de succession qu'il eût recueillie en l'absence de
conjoint survivant.

Ceux qui auront exercé cette faculté pourront exiger que soient appliquées les
dispositions de l'article 1094-3.
