Article 1041
----
La condition qui, dans l'intention du testateur, ne fait que suspendre
l'exécution de la disposition, n'empêchera pas l'héritier institué, ou le
légataire, d'avoir un droit acquis et transmissible à ses héritiers.
