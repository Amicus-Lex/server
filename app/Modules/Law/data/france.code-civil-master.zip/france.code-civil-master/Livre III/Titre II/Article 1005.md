Article 1005
----
Néanmoins, dans les mêmes cas, le légataire universel aura la jouissance des
biens compris dans le testament, à compter du jour du décès, si la demande en
délivrance a été faite dans l'année, depuis cette époque ; sinon, cette
jouissance ne commencera que du jour de la demande formée en justice, ou du jour
que la délivrance aurait été volontairement consentie.
