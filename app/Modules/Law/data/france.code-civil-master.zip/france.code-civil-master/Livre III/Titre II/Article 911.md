Article 911
----
Toute libéralité au profit d'une personne physique, frappée d'une incapacité de
recevoir à titre gratuit, est nulle, qu'elle soit déguisée sous la forme d'un
contrat onéreux ou faite sous le nom de personnes interposées, physiques ou
morales.

Sont présumés personnes interposées, jusqu'à preuve contraire, les père et mère,
les enfants et descendants, ainsi que l'époux de la personne incapable.
