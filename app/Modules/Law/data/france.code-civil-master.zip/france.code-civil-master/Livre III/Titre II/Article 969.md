Article 969
----
Un testament pourra être olographe ou fait par acte public ou dans la forme
mystique.
