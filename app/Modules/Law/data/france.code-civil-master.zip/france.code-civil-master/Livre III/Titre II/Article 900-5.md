Article 900-5
----
La demande n'est recevable que dix années après la mort du disposant ou, en cas
de demandes successives, dix années après le jugement qui a ordonné la
précédente révision.

La personne gratifiée doit justifier des diligences qu'elle a faites, dans
l'intervalle, pour exécuter ses obligations.
