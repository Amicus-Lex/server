Article 946
----
En cas que le donateur se soit réservé la liberté de disposer d'un effet compris
dans la donation ou d'une somme fixe sur les biens donnés, s'il meurt sans en
avoir disposé, ledit effet ou ladite somme appartiendra aux héritiers du
donateur, nonobstant toutes clauses et stipulations à ce contraires.
