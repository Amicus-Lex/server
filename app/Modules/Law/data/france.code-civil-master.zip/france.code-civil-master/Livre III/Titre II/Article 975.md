Article 975
----
Ne pourront être pris pour témoins du testament par acte public, ni les
légataires, à quelque titre qu'ils soient, ni leurs parents ou alliés jusqu'au
quatrième degré inclusivement, ni les clercs des notaires par lesquels les actes
seront reçus.
