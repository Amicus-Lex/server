Article 927
----
Néanmoins dans tous les cas où le testateur aura expressément déclaré qu'il
entend que tel legs soit acquitté de préférence aux autres, cette préférence
aura lieu ; et le legs qui en sera l'objet ne sera réduit qu'autant que la
valeur des autres ne remplirait pas la réserve légale.
