Article 1079
----
Le testament-partage produit les effets d'un partage. Ses bénéficiaires ne
peuvent renoncer à se prévaloir du testament pour réclamer un nouveau partage de
la succession.
