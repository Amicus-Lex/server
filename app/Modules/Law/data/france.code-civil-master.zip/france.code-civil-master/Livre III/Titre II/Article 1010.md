Article 1010
----
Le legs à titre universel est celui par lequel le testateur lègue une quote-part
des biens dont la loi lui permet de disposer, telle qu'une moitié, un tiers, ou
tous ses immeubles, ou tout son mobilier, ou une quotité fixe de tous ses
immeubles ou de tout son mobilier.

Tout autre legs ne forme qu'une disposition à titre particulier.
