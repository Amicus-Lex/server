Article 1099
----
Les époux ne pourront se donner indirectement au-delà de ce qui leur est permis
par les dispositions ci-dessus.
