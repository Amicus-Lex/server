Article 1033
----
L'exécuteur testamentaire rend compte dans les six mois suivant la fin de sa
mission.

Si l'exécution testamentaire prend fin par le décès de l'exécuteur, l'obligation
de rendre des comptes incombe à ses héritiers.

Il assume la responsabilité d'un mandataire à titre gratuit.
