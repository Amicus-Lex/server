Article 1078-7
----
Les donations-partages faites à des descendants de degrés différents peuvent
comporter les conventions prévues par les articles 1078-1 à 1078-3.
