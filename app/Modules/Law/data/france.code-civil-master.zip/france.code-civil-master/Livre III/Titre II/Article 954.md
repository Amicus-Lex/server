Article 954
----
Dans le cas de la révocation pour cause d'inexécution des conditions, les biens
rentreront dans les mains du donateur, libres de toutes charges et hypothèques
du chef du donataire ; et le donateur aura, contre les tiers détenteurs des
immeubles donnés, tous les droits qu'il aurait contre le donataire lui-même.
