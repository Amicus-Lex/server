Article 989
----
Sur les bâtiments de l'Etat, le testament de l'officier d'administration sera,
dans les circonstances prévues à l'article précédent, reçu par le commandant ou
par celui qui en remplit les fonctions, et, s'il n'y a pas d'officier
d'administration, le testament du commandant sera reçu par celui qui vient après
lui dans l'ordre du service.

Sur les autres bâtiments, le testament du capitaine, maître ou patron, ou celui
du second, seront, dans les mêmes circonstances, reçus par les personnes qui
viennent après eux dans l'ordre du service.
