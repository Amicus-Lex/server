Article 1006
----
Lorsqu'au décès du testateur il n'y aura pas d'héritiers auxquels une quotité de
ses biens soit réservée par la loi, le légataire universel sera saisi de plein
droit par la mort du testateur, sans être tenu de demander la délivrance.
