Article 985
----
Les testaments faits dans un lieu avec lequel toute communication est impossible
à cause d'une maladie contagieuse peuvent être faits par toute personne atteinte
de cette maladie ou située dans des lieux qui en sont infectés, devant le juge
d'instance ou devant l'un des officiers municipaux de la commune, en présence de
deux témoins.
