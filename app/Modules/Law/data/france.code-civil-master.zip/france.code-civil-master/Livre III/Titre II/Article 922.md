Article 922
----
La réduction se détermine en formant une masse de tous les biens existant au
décès du donateur ou testateur.

Les biens dont il a été disposé par donation entre vifs sont fictivement réunis
à cette masse, d'après leur état à l'époque de la donation et leur valeur à
l'ouverture de la succession, après qu'en ont été déduites les dettes ou les
charges les grevant. Si les biens ont été aliénés, il est tenu compte de leur
valeur à l'époque de l'aliénation. S'il y a eu subrogation, il est tenu compte
de la valeur des nouveaux biens au jour de l'ouverture de la succession, d'après
leur état à l'époque de l'acquisition. Toutefois, si la dépréciation des
nouveaux biens était, en raison de leur nature, inéluctable au jour de leur
acquisition, il n'est pas tenu compte de la subrogation.

On calcule sur tous ces biens, eu égard à la qualité des héritiers qu'il laisse,
quelle est la quotité dont le défunt a pu disposer.
