Article 947
----
Les quatre articles précédents ne s'appliquent point aux donations dont est
mention aux chapitres VIII et IX du présent titre.
