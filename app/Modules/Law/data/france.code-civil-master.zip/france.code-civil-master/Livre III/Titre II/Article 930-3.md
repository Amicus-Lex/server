Article 930-3
----
Le renonçant ne peut demander la révocation de sa renonciation que si :

1° Celui dont il a vocation à hériter ne remplit pas ses obligations
alimentaires envers lui ;

2° Au jour de l'ouverture de la succession, il est dans un état de besoin qui
disparaîtrait s'il n'avait pas renoncé à ses droits réservataires ;

3° Le bénéficiaire de la renonciation s'est rendu coupable d'un crime ou d'un
délit contre sa personne.
