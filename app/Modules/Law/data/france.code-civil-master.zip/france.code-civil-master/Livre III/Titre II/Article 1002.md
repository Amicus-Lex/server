Article 1002
----
Les dispositions testamentaires sont ou universelles, ou à titre universel, ou à
titre particulier.

Chacune de ces dispositions, soit qu'elle ait été faite sous la dénomination
d'institution d'héritier, soit qu'elle ait été faite sous la dénomination de
legs, produira son effet suivant les règles ci-après établies pour les legs
universels, pour les legs à titre universel, et pour les legs particuliers.
