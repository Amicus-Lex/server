Article 912
----
La réserve héréditaire est la part des biens et droits successoraux dont la loi
assure la dévolution libre de charges à certains héritiers dits réservataires,
s'ils sont appelés à la succession et s'ils l'acceptent.

La quotité disponible est la part des biens et droits successoraux qui n'est pas
réservée par la loi et dont le défunt a pu disposer librement par des
libéralités.
