Article 931
----
Tous actes portant donation entre vifs seront passés devant notaires dans la
forme ordinaire des contrats ; et il en restera minute, sous peine de nullité.
