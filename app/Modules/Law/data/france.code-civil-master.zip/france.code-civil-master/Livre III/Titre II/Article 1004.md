Article 1004
----
Lorsqu'au décès du testateur il y a des héritiers auxquels une quotité de ses
biens est réservée par la loi, ces héritiers sont saisis de plein droit, par sa
mort, de tous les biens de la succession ; et le légataire universel est tenu de
leur demander la délivrance des biens compris dans le testament.
