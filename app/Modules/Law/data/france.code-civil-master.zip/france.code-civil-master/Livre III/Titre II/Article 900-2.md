Article 900-2
----
Tout gratifié peut demander que soient révisées en justice les conditions et
charges grevant les donations ou legs qu'il a reçus, lorsque, par suite d'un
changement de circonstances, l'exécution en est devenue pour lui soit
extrêmement difficile, soit sérieusement dommageable.
