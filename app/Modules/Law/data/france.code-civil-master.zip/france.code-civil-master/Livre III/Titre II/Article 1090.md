Article 1090
----
Toutes donations faites aux époux par leur contrat de mariage seront, lors de
l'ouverture de la succession du donateur, réductibles à la portion dont la loi
lui permettait de disposer.
