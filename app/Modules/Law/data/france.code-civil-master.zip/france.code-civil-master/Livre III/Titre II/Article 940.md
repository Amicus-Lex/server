Article 940
----
Lorsque la donation sera faite à des mineurs, à des majeurs en tutelle ou à des
établissements publics, la publication sera faite à la diligence des tuteurs,
curateurs ou administrateurs.
