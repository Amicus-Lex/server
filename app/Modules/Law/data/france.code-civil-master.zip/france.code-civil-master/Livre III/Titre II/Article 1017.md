Article 1017
----
Les héritiers du testateur, ou autres débiteurs d'un legs, seront
personnellement tenus de l'acquitter, chacun au prorata de la part et portion
dont ils profiteront dans la succession.

Ils en seront tenus hypothécairement pour le tout, jusqu'à concurrence de la
valeur des immeubles de la succession dont ils seront détenteurs.
