Article 984
----
Le testament fait dans la forme ci-dessus établie sera nul six mois après que le
testateur sera venu dans un lieu où il aura la liberté d'employer les formes
ordinaires, à moins que, avant l'expiration de ce délai, il n'ait été de nouveau
placé dans une des situations spéciales prévues à l'article 93. Le testament
sera alors valable pendant la durée de cette situation spéciale et pendant un
nouveau délai de six mois après son expiration.
