Article 968
----
Un testament ne pourra être fait dans le même acte par deux ou plusieurs
personnes soit au profit d'un tiers, soit à titre de disposition réciproque ou
mutuelle.
