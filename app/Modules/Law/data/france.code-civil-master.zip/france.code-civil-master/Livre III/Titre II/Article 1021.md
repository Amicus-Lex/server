Article 1021
----
Lorsque le testateur aura légué la chose d'autrui, le legs sera nul, soit que le
testateur ait connu ou non qu'elle ne lui appartenait pas.
