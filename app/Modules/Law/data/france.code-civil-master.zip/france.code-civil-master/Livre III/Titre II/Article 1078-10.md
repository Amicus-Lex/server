Article 1078-10
----
Les règles édictées à l'article 1078-9 ne s'appliquent pas lorsque l'enfant qui
a consenti à ce que ses propres descendants soient allotis en son lieu et place
procède ensuite lui-même, avec ces derniers, à une donation-partage à laquelle
sont incorporés les biens antérieurement reçus dans les conditions prévues à
l'article 1078-4.

Cette nouvelle donation-partage peut comporter les conventions prévues par les
articles 1078-1 et 1078-2.
