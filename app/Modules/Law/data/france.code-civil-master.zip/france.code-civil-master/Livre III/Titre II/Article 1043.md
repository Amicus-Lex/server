Article 1043
----
La disposition testamentaire sera caduque lorsque l'héritier institué ou le
légataire la répudiera ou se trouvera incapable de la recueillir.
