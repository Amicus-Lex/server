Article 964
----
La mort de l'enfant du donateur est sans effet sur la révocation des donations
prévue à l'article 960.
