Article 924-1
----
Le gratifié peut exécuter la réduction en nature, par dérogation à l'article
924, lorsque le bien donné ou légué lui appartient encore et qu'il est libre de
toute charge dont il n'aurait pas déjà été grevé à la date de la libéralité,
ainsi que de toute occupation dont il n'aurait pas déjà fait l'objet à cette
même date.

Cette faculté s'éteint s'il n'exprime pas son choix pour cette modalité de
réduction dans un délai de trois mois à compter de la date à laquelle un
héritier réservataire l'a mis en demeure de prendre parti.
