Article 920
----
Les libéralités, directes ou indirectes, qui portent atteinte à la réserve d'un
ou plusieurs héritiers, sont réductibles à la quotité disponible lors de
l'ouverture de la succession.
