Article 1054
----
Si le grevé est héritier réservataire du disposant, la charge ne peut être
imposée que sur la quotité disponible.

Le donataire peut toutefois accepter, dans l'acte de donation ou postérieurement
dans un acte établi dans les conditions prévues à l'article 930, que la charge
grève tout ou partie de sa réserve.

Le légataire peut, dans un délai d'un an à compter du jour où il a eu
connaissance du testament, demander que sa part de réserve soit, en tout ou
partie, libérée de la charge. A défaut, il doit en assumer l'exécution.

La charge portant sur la part de réserve du grevé, avec son consentement,
bénéficie de plein droit, dans cette mesure, à l'ensemble de ses enfants nés et
à naître.
