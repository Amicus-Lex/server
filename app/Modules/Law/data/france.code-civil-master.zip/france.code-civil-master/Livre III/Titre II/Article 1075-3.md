Article 1075-3
----
L'action en complément de part pour cause de lésion ne peut être exercée contre
les donations-partages et les testaments-partages.
