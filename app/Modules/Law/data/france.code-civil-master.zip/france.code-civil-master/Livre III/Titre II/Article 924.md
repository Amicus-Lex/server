Article 924
----
Lorsque la libéralité excède la quotité disponible, le gratifié, successible ou
non successible, doit indemniser les héritiers réservataires à concurrence de la
portion excessive de la libéralité, quel que soit cet excédent.

Le paiement de l'indemnité par l'héritier réservataire se fait en moins prenant
et en priorité par voie d'imputation sur ses droits dans la réserve.
