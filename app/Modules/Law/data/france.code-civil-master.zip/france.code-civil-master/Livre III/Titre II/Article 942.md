Article 942
----
Les mineurs, les majeurs en tutelle ne seront point restitués contre le défaut
d'acceptation ou de publication des donations ; sauf leur recours contre leurs
tuteurs, s'il y échet, et sans que la restitution puisse avoir lieu, dans le cas
même où lesdits tuteurs se trouveraient insolvables.
