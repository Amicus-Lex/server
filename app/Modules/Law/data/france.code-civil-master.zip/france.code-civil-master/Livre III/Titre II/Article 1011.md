Article 1011
----
Les légataires à titre universel seront tenus de demander la délivrance aux
héritiers auxquels une quotité des biens est réservée par la loi ; à leur
défaut, aux légataires universels et, à défaut de ceux-ci, aux héritiers appelés
dans l'ordre établi au titre " Des successions ".
