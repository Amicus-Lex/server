Article 974
----
Le testament devra être signé par les témoins et par le notaire.
