Article 1035
----
Les testaments ne pourront être révoqués, en tout ou en partie, que par un
testament postérieur ou par un acte devant notaires portant déclaration du
changement de volonté.
