Article 961
----
Cette révocation peut avoir lieu, encore que l'enfant du donateur ou de la
donatrice fût conçu au temps de la donation.
