Article 1075
----
Toute personne peut faire, entre ses héritiers présomptifs, la distribution et
le partage de ses biens et de ses droits.

Cet acte peut se faire sous forme de donation-partage ou de testament-partage.
Il est soumis aux formalités, conditions et règles prescrites pour les donations
entre vifs dans le premier cas et pour les testaments dans le second.
