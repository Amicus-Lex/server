Article 1023
----
Le legs fait au créancier ne sera pas censé en compensation de sa créance, ni le
legs fait au domestique en compensation de ses gages.
