Article 913-1
----
Sont compris dans l'article 913, sous le nom d'enfants, les descendants en
quelque degré que ce soit, encore qu'ils ne doivent être comptés que pour
l'enfant dont ils tiennent la place dans la succession du disposant.
