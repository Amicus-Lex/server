Article 980
----
Les témoins appelés pour être présents aux testaments devront comprendre la
langue française et être majeurs, savoir signer et avoir la jouissance de leurs
droits civils. Ils pourront être de l'un ou de l'autre sexe, mais le mari et la
femme ne pourront être témoins dans le même acte.
