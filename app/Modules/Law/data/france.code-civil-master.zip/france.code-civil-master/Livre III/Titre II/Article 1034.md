Article 1034
----
Les frais supportés par l'exécuteur testamentaire dans l'exercice de sa mission
sont à la charge de la succession.
