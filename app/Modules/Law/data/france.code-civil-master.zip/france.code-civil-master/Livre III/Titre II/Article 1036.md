Article 1036
----
Les testaments postérieurs, qui ne révoqueront pas d'une manière expresse les
précédents, n'annuleront, dans ceux-ci, que celles des dispositions y contenues
qui se trouveront incompatibles avec les nouvelles ou qui seront contraires.
