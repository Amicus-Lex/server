Article 957
----
La demande en révocation pour cause d'ingratitude devra être formée dans
l'année, à compter du jour du délit imputé par le donateur au donataire, ou du
jour que le délit aura pu être connu par le donateur.

Cette révocation ne pourra être demandée par le donateur contre les héritiers du
donataire, ni par les héritiers du donateur contre le donataire, à moins que,
dans ce dernier cas, l'action n'ait été intentée par le donateur, ou qu'il ne
soit décédé dans l'année du délit.
