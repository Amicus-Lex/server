Article 928
----
Lorsque la réduction s'exécute en nature, le donataire restitue les fruits de ce
qui excède la portion disponible, à compter du jour du décès du donateur, si la
demande en réduction est faite dans l'année ; sinon, du jour de la demande.
