Article 1019
----
Lorsque celui qui a légué la propriété d'un immeuble, l'a ensuite augmentée par
des acquisitions, ces acquisitions, fussent-elles contiguës, ne seront pas
censées, sans une nouvelle disposition, faire partie du legs.

Il en sera autrement des embellissements, ou des constructions nouvelles faites
sur le fonds légué, ou d'un enclos dont le testateur aurait augmenté l'enceinte.
