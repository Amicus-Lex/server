Article 1056
----
Lorsque le second gratifié prédécède au grevé ou renonce au bénéfice de la
libéralité graduelle, les biens ou droits qui en faisaient l'objet dépendent de
la succession du grevé, à moins que l'acte prévoit expressément que ses
héritiers pourront la recueillir ou désigne un autre second gratifié.
