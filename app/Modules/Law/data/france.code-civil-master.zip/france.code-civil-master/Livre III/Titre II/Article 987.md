Article 987
----
Les testaments mentionnés aux deux précédents articles deviendront nuls six mois
après que les communications auront été rétablies dans le lieu où le testateur
se trouve, ou six mois après qu'il aura passé dans un lieu où elles ne seront
point interrompues.
