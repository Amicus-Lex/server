Article 918
----
La valeur en pleine propriété des biens aliénés, soit à charge de rente viagère,
soit à fonds perdus, ou avec réserve d'usufruit à l'un des successibles en ligne
directe, est imputée sur la quotité disponible. L'éventuel excédent est sujet à
réduction. Cette imputation et cette réduction ne peuvent être demandées que par
ceux des autres successibles en ligne directe qui n'ont pas consenti à ces
aliénations.
