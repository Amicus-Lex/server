Article 935
----
La donation faite à un mineur non émancipé ou à un majeur en tutelle devra être
acceptée par son tuteur, conformément à l'article 463, au titre " De la
minorité, de la tutelle et de l'émancipation ".

Néanmoins, les père et mère du mineur non émancipé, ou les autres ascendants,
même du vivant des père et mère, quoiqu'ils ne soient pas tuteurs du mineur,
pourront accepter pour lui.
