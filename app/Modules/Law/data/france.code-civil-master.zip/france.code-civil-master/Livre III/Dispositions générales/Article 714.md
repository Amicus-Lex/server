Article 714
----
Il est des choses qui n'appartiennent à personne et dont l'usage est commun à
tous.

Des lois de police règlent la manière d'en jouir.
