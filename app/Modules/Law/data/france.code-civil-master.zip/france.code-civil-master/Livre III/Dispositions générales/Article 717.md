Article 717
----
Les droits sur les effets jetés à la mer, sur les objets que la mer rejette, de
quelque nature qu'ils puissent être, sur les plantes et herbages qui croissent
sur les rivages de la mer, sont aussi réglés par des lois particulières.

Il en est de même des choses perdues dont le maître ne se représente pas.
