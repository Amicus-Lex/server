Article 715
----
La faculté de chasser ou de pêcher est également réglée par des lois
particulières.
