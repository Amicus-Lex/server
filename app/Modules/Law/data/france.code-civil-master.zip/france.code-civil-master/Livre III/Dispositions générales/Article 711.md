Article 711
----
La propriété des biens s'acquiert et se transmet par succession, par donation
entre vifs ou testamentaire, et par l'effet des obligations.
