Article 712
----
La propriété s'acquiert aussi par accession ou incorporation, et par
prescription.
