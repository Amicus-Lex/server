Article 713
----
Les biens qui n'ont pas de maître appartiennent à la commune sur le territoire
de laquelle ils sont situés. Par délibération du conseil municipal, la commune
peut renoncer à exercer ses droits, sur tout ou partie de son territoire, au
profit de l'établissement public de coopération intercommunale à fiscalité
propre dont elle est membre. Les biens sans maître sont alors réputés appartenir
à l'établissement public de coopération intercommunale à fiscalité propre.

Toutefois, la propriété est transférée de plein droit à l'Etat si la commune
renonce à exercer ses droits en l'absence de délibération telle que définie au
premier alinéa ou si l'établissement public de coopération intercommunale à
fiscalité propre renonce à exercer ses droits.
