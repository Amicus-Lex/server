Article 690
----
Les servitudes continues et apparentes s'acquièrent par titre, ou par la
possession de trente ans.
