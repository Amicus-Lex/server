Article 701
----
Le propriétaire du fonds débiteur de la servitude ne peut rien faire qui tende à
en diminuer l'usage, ou à le rendre plus incommode.

Ainsi, il ne peut changer l'état des lieux, ni transporter l'exercice de la
servitude dans un endroit différent de celui où elle a été primitivement
assignée.

Mais cependant, si cette assignation primitive était devenue plus onéreuse au
propriétaire du fonds assujetti, ou si elle l'empêchait d'y faire des
réparations avantageuses, il pourrait offrir au propriétaire de l'autre fonds un
endroit aussi commode pour l'exercice de ses droits, et celui-ci ne pourrait pas
le refuser.
