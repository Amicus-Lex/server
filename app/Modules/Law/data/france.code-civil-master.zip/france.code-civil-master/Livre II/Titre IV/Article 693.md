Article 693
----
Il n'y a destination du père de famille que lorsqu'il est prouvé que les deux
fonds actuellement divisés ont appartenu au même propriétaire, et que c'est par
lui que les choses ont été mises dans l'état duquel résulte la servitude.
