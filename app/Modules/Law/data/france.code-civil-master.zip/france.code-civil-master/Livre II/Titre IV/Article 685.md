Article 685
----
L'assiette et le mode de servitude de passage pour cause d'enclave sont
déterminés par trente ans d'usage continu.

L'action en indemnité, dans le cas prévu par l'article 682, est prescriptible,
et le passage peut être continué, quoique l'action en indemnité ne soit plus
recevable.
