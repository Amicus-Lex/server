Article 640
----
Les fonds inférieurs sont assujettis envers ceux qui sont plus élevés à recevoir
les eaux qui en découlent naturellement sans que la main de l'homme y ait
contribué.

Le propriétaire inférieur ne peut point élever de digue qui empêche cet
écoulement.

Le propriétaire supérieur ne peut rien faire qui aggrave la servitude du fonds
inférieur.
