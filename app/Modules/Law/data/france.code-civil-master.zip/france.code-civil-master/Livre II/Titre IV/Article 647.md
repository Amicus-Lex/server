Article 647
----
Tout propriétaire peut clore son héritage, sauf l'exception portée en l'article
682.
