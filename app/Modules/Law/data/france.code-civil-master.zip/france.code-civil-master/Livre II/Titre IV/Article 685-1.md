Article 685-1
----
En cas de cessation de l'enclave et quelle que soit la manière dont l'assiette
et le mode de la servitude ont été déterminés, le propriétaire du fonds servant
peut, à tout moment, invoquer l'extinction de la servitude si la desserte du
fonds dominant est assurée dans les conditions de l'article 682.

A défaut d'accord amiable, cette disparition est constatée par une décision de
justice.
