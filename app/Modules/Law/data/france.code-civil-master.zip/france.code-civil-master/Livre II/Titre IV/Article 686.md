Article 686
----
Il est permis aux propriétaires d'établir sur leurs propriétés, ou en faveur de
leurs propriétés, telles servitudes que bon leur semble, pourvu néanmoins que
les services établis ne soient imposés ni à la personne, ni en faveur de la
personne, mais seulement à un fonds et pour un fonds, et pourvu que ces services
n'aient d'ailleurs rien de contraire à l'ordre public.

L'usage et l'étendue des servitudes ainsi établies se règlent par le titre qui
les constitue ; à défaut de titre, par les règles ci-après.
