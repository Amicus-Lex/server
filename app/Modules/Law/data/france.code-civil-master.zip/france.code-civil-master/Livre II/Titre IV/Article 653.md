Article 653
----
Dans les villes et les campagnes, tout mur servant de séparation entre bâtiments
jusqu'à l'héberge, ou entre cours et jardins, et même entre enclos dans les
champs, est présumé mitoyen s'il n'y a titre ou marque du contraire.
