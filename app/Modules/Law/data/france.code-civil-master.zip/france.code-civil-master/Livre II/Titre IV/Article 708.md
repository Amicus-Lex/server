Article 708
----
Le mode de la servitude peut se prescrire comme la servitude même, et de la même
manière.
