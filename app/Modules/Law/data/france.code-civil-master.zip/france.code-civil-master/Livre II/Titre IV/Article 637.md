Article 637
----
Une servitude est une charge imposée sur un héritage pour l'usage et l'utilité
d'un héritage appartenant à un autre propriétaire.
