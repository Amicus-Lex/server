Article 654
----
Il y a marque de non-mitoyenneté lorsque la sommité du mur est droite et à plomb
de son parement d'un côté, et présente de l'autre un plan incliné.

Lors encore qu'il n'y a que d'un côté ou un chaperon ou des filets et corbeaux
de pierre qui y auraient été mis en bâtissant le mur.

Dans ces cas, le mur est censé appartenir exclusivement au propriétaire du côté
duquel sont l'égout ou les corbeaux et filets de pierre.
