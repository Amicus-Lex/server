Article 688
----
Les servitudes sont ou continues, ou discontinues.

Les servitudes continues sont celles dont l'usage est ou peut être continuel
sans avoir besoin du fait actuel de l'homme : tels sont les conduites d'eau, les
égouts, les vues et autres de cette espèce.

Les servitudes discontinues sont celles qui ont besoin du fait actuel de l'homme
pour être exercées : tels sont les droits de passage, puisage, pacage et autres
semblables.
