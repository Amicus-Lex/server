Article 679
----
On ne peut, sous la même réserve, avoir des vues par côté ou obliques sur le
même héritage, s'il n'y a six décimètres de distance.
