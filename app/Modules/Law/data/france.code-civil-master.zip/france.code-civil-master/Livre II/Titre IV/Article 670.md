Article 670
----
Les arbres qui se trouvent dans la haie mitoyenne sont mitoyens comme la haie.
Les arbres plantés sur la ligne séparative de deux héritages sont aussi réputés
mitoyens. Lorsqu'ils meurent ou lorsqu'ils sont coupés ou arrachés, ces arbres
sont partagés par moitié. Les fruits sont recueillis à frais communs et partagés
aussi par moitié, soit qu'ils tombent naturellement, soit que la chute en ait
été provoquée, soit qu'ils aient été cueillis.

Chaque propriétaire a le droit d'exiger que les arbres mitoyens soient arrachés.
