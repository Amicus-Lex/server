Article 678
----
On ne peut avoir des vues droites ou fenêtres d'aspect, ni balcons ou autres
semblables saillies sur l'héritage clos ou non clos de son voisin, s'il n'y a
dix-neuf décimètres de distance entre le mur où on les pratique et ledit
héritage, à moins que le fonds ou la partie du fonds sur lequel s'exerce la vue
ne soit déjà grevé, au profit du fonds qui en bénéficie, d'une servitude de
passage faisant obstacle à l'édification de constructions.
