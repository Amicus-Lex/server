Article 683
----
Le passage doit régulièrement être pris du côté où le trajet est le plus court
du fonds enclavé à la voie publique.

Néanmoins, il doit être fixé dans l'endroit le moins dommageable à celui sur le
fonds duquel il est accordé.
