Article 704
----
Elles revivent si les choses sont rétablies de manière qu'on puisse en user ; à
moins qu'il ne se soit déjà écoulé un espace de temps suffisant pour faire
présumer l'extinction de la servitude, ainsi qu'il est dit à l'article 707.
