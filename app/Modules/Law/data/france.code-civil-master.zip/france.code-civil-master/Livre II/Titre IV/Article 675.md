Article 675
----
L'un des voisins ne peut, sans le consentement de l'autre, pratiquer dans le mur
mitoyen aucune fenêtre ou ouverture, en quelque manière que ce soit, même à
verre dormant.
