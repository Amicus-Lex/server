Article 684
----
Si l'enclave résulte de la division d'un fonds par suite d'une vente, d'un
échange, d'un partage ou de tout autre contrat, le passage ne peut être demandé
que sur les terrains qui ont fait l'objet de ces actes.

Toutefois, dans le cas où un passage suffisant ne pourrait être établi sur les
fonds divisés, l'article 682 serait applicable.
