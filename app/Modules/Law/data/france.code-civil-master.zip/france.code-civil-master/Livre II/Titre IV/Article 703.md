Article 703
----
Les servitudes cessent lorsque les choses se trouvent en tel état qu'on ne peut
plus en user.
