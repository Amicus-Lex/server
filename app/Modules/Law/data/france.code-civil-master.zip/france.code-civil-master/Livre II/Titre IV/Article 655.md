Article 655
----
La réparation et la reconstruction du mur mitoyen sont à la charge de tous ceux
qui y ont droit, et proportionnellement au droit de chacun.
