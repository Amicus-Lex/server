Article 658
----
Tout copropriétaire peut faire exhausser le mur mitoyen ; mais il doit payer
seul la dépense de l'exhaussement et les réparations d'entretien au-dessus de la
hauteur de la clôture commune ; il doit en outre payer seul les frais
d'entretien de la partie commune du mur dus à l'exhaussement et rembourser au
propriétaire voisin toutes les dépenses rendues nécessaires à ce dernier par
l'exhaussement.
