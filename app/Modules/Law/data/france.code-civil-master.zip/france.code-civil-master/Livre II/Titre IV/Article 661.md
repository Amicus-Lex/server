Article 661
----
Tout propriétaire joignant un mur a la faculté de le rendre mitoyen en tout ou
en partie, en remboursant au maître du mur la moitié de la dépense qu'il a
coûté, ou la moitié de la dépense qu'a coûté la portion du mur qu'il veut rendre
mitoyenne et la moitié de la valeur du sol sur lequel le mur est bâti. La
dépense que le mur a coûté est estimée à la date de l'acquisition de sa
mitoyenneté, compte tenu de l'état dans lequel il se trouve.
