Article 698
----
Ces ouvrages sont à ses frais, et non à ceux du propriétaire du fonds assujetti,
à moins que le titre d'établissement de la servitude ne dise le contraire.
