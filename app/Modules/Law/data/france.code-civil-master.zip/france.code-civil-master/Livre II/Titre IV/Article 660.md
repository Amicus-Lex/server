Article 660
----
Le voisin qui n'a pas contribué à l'exhaussement peut en acquérir la mitoyenneté
en payant la moitié de la dépense qu'il a coûté et la valeur de la moitié du sol
fourni pour l'excédent d'épaisseur, s'il y en a. La dépense que l'exhaussement a
coûté est estimée à la date de l'acquisition, compte tenu de l'état dans lequel
se trouve la partie exhaussée du mur.
