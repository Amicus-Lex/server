Article 641
----
Tout propriétaire a le droit d'user et de disposer des eaux pluviales qui
tombent sur son fonds.

Si l'usage de ces eaux ou la direction qui leur est donnée aggrave la servitude
naturelle d'écoulement établie par l'article 640, une indemnité est due au
propriétaire du fonds inférieur.

La même disposition est applicable aux eaux de sources nées sur un fonds.

Lorsque, par des sondages ou des travaux souterrains, un propriétaire fait
surgir des eaux dans son fonds, les propriétaires des fonds inférieurs doivent
les recevoir ; mais ils ont droit à une indemnité en cas de dommages résultant
de leur écoulement.

Les maisons, cours, jardins, parcs et enclos attenant aux habitations ne peuvent
être assujettis à aucune aggravation de la servitude d'écoulement dans les cas
prévus par les paragraphes précédents.

Les contestations auxquelles peuvent donner lieu l'établissement et l'exercice
des servitudes prévues par ces paragraphes et le règlement, s'il y a lieu, des
indemnités dues aux propriétaires des fonds inférieurs sont portées, en premier
ressort, devant le juge du tribunal d'instance du canton qui, en prononçant,
doit concilier les intérêts de l'agriculture et de l'industrie avec le respect
dû à la propriété.

S'il y a lieu à expertise, il peut n'être nommé qu'un seul expert.
