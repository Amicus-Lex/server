Article 667
----
La clôture mitoyenne doit être entretenue à frais communs ; mais le voisin peut
se soustraire à cette obligation en renonçant à la mitoyenneté.

Cette faculté cesse si le fossé sert habituellement à l'écoulement des eaux.
