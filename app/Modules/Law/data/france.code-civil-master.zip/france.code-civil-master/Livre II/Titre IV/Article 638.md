Article 638
----
La servitude n'établit aucune prééminence d'un héritage sur l'autre.
