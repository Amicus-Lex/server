Article 656
----
Cependant tout copropriétaire d'un mur mitoyen peut se dispenser de contribuer
aux réparations et reconstructions en abandonnant le droit de mitoyenneté,
pourvu que le mur mitoyen ne soutienne pas un bâtiment qui lui appartienne.
