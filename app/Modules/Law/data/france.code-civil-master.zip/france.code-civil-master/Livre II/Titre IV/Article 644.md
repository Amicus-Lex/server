Article 644
----
Celui dont la propriété borde une eau courante, autre que celle qui est déclarée
dépendance du domaine public par l'article 538 au titre " De la distinction des
biens ", peut s'en servir à son passage pour l'irrigation de ses propriétés.

Celui dont cette eau traverse l'héritage peut même en user dans l'intervalle
qu'elle y parcourt, mais à la charge de la rendre, à la sortie de ses fonds, à
son cours ordinaire.
