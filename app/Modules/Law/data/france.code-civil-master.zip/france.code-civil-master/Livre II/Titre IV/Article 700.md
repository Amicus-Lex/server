Article 700
----
Si l'héritage pour lequel la servitude a été établie vient à être divisé, la
servitude reste due pour chaque portion, sans néanmoins que la condition du
fonds assujetti soit aggravée.

Ainsi, par exemple, s'il s'agit d'un droit de passage, tous les copropriétaires
seront obligés de l'exercer par le même endroit.
