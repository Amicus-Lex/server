Article 652
----
Partie de ces obligations est réglée par les lois sur la police rurale ;

Les autres sont relatives au mur et au fossé mitoyens, au cas où il y a lieu à
contre-mur, aux vues sur la propriété du voisin, à l'égout des toits, au droit
de passage.
