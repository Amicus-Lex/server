Article 669
----
Tant que dure la mitoyenneté de la haie, les produits en appartiennent aux
propriétaires par moitié.
