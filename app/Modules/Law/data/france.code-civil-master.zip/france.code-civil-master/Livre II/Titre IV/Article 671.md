Article 671
----
Il n'est permis d'avoir des arbres, arbrisseaux et arbustes près de la limite de
la propriété voisine qu'à la distance prescrite par les règlements particuliers
actuellement existants, ou par des usages constants et reconnus et, à défaut de
règlements et usages, qu'à la distance de deux mètres de la ligne séparative des
deux héritages pour les plantations dont la hauteur dépasse deux mètres, et à la
distance d'un demi-mètre pour les autres plantations.

Les arbres, arbustes et arbrisseaux de toute espèce peuvent être plantés en
espaliers, de chaque côté du mur séparatif, sans que l'on soit tenu d'observer
aucune distance, mais ils ne pourront dépasser la crête du mur.

Si le mur n'est pas mitoyen, le propriétaire seul a le droit d'y appuyer les
espaliers.
