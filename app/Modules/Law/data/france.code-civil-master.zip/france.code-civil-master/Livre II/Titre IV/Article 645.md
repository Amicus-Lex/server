Article 645
----
S'il s'élève une contestation entre les propriétaires auxquels ces eaux peuvent
être utiles, les tribunaux, en prononçant, doivent concilier l'intérêt de
l'agriculture avec le respect dû à la propriété ; et, dans tous les cas, les
règlements particuliers et locaux sur le cours et l'usage des eaux doivent être
observés.
