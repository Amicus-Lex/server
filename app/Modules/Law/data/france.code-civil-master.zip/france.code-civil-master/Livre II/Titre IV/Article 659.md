Article 659
----
Si le mur mitoyen n'est pas en état de supporter l'exhaussement, celui qui veut
l'exhausser doit le faire reconstruire en entier à ses frais, et l'excédent
d'épaisseur doit se prendre de son côté.
