Article 643
----
Si, dès la sortie du fonds où elles surgissent, les eaux de source forment un
cours d'eau offrant le caractère d'eaux publiques et courantes, le propriétaire
ne peut les détourner de leurs cours naturel au préjudice des usagers
inférieurs.
