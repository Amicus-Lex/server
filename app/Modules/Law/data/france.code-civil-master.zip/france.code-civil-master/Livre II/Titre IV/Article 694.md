Article 694
----
Si le propriétaire de deux héritages entre lesquels il existe un signe apparent
de servitude, dispose de l'un des héritages sans que le contrat contienne aucune
convention relative à la servitude, elle continue d'exister activement ou
passivement en faveur du fonds aliéné ou sur le fonds aliéné.
