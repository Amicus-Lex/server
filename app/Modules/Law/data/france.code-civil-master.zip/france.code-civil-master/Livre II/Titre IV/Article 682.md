Article 682
----
Le propriétaire dont les fonds sont enclavés et qui n'a sur la voie publique
aucune issue, ou qu'une issue insuffisante, soit pour l'exploitation agricole,
industrielle ou commerciale de sa propriété, soit pour la réalisation
d'opérations de construction ou de lotissement, est fondé à réclamer sur les
fonds de ses voisins un passage suffisant pour assurer la desserte complète de
ses fonds, à charge d'une indemnité proportionnée au dommage qu'il peut
occasionner.
