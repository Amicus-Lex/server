Article 695
----
Le titre constitutif de la servitude, à l'égard de celles qui ne peuvent
s'acquérir par la prescription, ne peut être remplacé que par un titre
récognitif de la servitude, et émané du propriétaire du fonds asservi.
