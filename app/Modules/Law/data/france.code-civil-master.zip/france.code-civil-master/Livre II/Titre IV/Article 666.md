Article 666
----
Toute clôture qui sépare des héritages est réputée mitoyenne, à moins qu'il n'y
ait qu'un seul des héritages en état de clôture, ou s'il n'y a titre,
prescription ou marque contraire.

Pour les fossés, il y a marque de non-mitoyenneté lorsque la levée ou le rejet
de la terre se trouve d'un côté seulement du fossé.

Le fossé est censé appartenir exclusivement à celui du côté duquel le rejet se
trouve.
