Article 651
----
La loi assujettit les propriétaires à différentes obligations l'un à l'égard de
l'autre, indépendamment de toute convention.
