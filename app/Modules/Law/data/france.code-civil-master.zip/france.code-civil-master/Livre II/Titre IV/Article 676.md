Article 676
----
Le propriétaire d'un mur non mitoyen, joignant immédiatement l'héritage
d'autrui, peut pratiquer dans ce mur des jours ou fenêtres à fer maillé et verre
dormant.

Ces fenêtres doivent être garnies d'un treillis de fer dont les mailles auront
un décimètre (environ trois pouces huit lignes) d'ouverture au plus et d'un
châssis à verre dormant.
