Article 657
----
Tout copropriétaire peut faire bâtir contre un mur mitoyen, et y faire placer
des poutres ou solives dans toute l'épaisseur du mur, à cinquante-quatre
millimètres près, sans préjudice du droit qu'a le voisin de faire réduire à
l'ébauchoir la poutre jusqu'à la moitié du mur, dans le cas où il voudrait lui-
même asseoir des poutres dans le même lieu, ou y adosser une cheminée.
