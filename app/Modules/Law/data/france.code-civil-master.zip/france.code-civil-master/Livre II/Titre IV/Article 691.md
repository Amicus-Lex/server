Article 691
----
Les servitudes continues non apparentes, et les servitudes discontinues
apparentes ou non apparentes, ne peuvent s'établir que par titres.

La possession même immémoriale ne suffit pas pour les établir, sans cependant
qu'on puisse attaquer aujourd'hui les servitudes de cette nature déjà acquises
par la possession, dans les pays où elles pouvaient s'acquérir de cette manière.
