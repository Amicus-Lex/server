Article 649
----
Les servitudes établies par la loi ont pour objet l'utilité publique ou
communale, ou l'utilité des particuliers.
