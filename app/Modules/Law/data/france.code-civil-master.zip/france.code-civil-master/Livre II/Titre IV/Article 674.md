Article 674
----
Celui qui fait creuser un puits ou une fosse d'aisance près d'un mur mitoyen ou
non,

Celui qui veut y construire cheminée ou âtre, forge, four ou fourneau,

Y adosser une étable,

Ou établir contre ce mur un magasin de sel ou amas de matières corrosives,

Est obligé à laisser la distance prescrite par les règlements et usages
particuliers sur ces objets, ou à faire les ouvrages prescrits par les mêmes
règlements et usages, pour éviter de nuire au voisin.
