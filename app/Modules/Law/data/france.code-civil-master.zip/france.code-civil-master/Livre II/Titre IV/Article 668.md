Article 668
----
Le voisin dont l'héritage joint un fossé ou une haie non mitoyens ne peut
contraindre le propriétaire de ce fossé ou de cette haie à lui céder la
mitoyenneté.

Le copropriétaire d'une haie mitoyenne peut la détruire jusqu'à la limite de sa
propriété, à la charge de construire un mur sur cette limite.

La même règle est applicable au copropriétaire d'un fossé mitoyen qui ne sert
qu'à la clôture.
