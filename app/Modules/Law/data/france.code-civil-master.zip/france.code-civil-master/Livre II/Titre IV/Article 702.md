Article 702
----
De son côté, celui qui a un droit de servitude ne peut en user que suivant son
titre, sans pouvoir faire, ni dans le fonds qui doit la servitude, ni dans le
fonds à qui elle est due, de changement qui aggrave la condition du premier.
