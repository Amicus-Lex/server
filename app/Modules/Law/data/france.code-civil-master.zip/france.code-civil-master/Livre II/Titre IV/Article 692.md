Article 692
----
La destination du père de famille vaut titre à l'égard des servitudes continues
et apparentes.
