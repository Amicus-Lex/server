Article 697
----
Celui auquel est due une servitude a droit de faire tous les ouvrages
nécessaires pour en user et pour la conserver.
