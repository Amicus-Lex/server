Article 706
----
La servitude est éteinte par le non-usage pendant trente ans.
