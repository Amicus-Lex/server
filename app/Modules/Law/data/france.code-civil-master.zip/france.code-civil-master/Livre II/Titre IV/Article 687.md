Article 687
----
Les servitudes sont établies ou pour l'usage des bâtiments, ou pour celui des
fonds de terre.

Celles de la première espèce s'appellent "urbaines", soit que les bâtiments
auxquels elles sont dues soient situés à la ville ou à la campagne.

Celles de la seconde espèce se nomment "rurales".
