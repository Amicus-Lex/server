Article 710
----
Si, parmi les copropriétaires, il s'en trouve un contre lequel la prescription
n'ait pu courir, comme un mineur, il aura conservé le droit de tous les autres.
