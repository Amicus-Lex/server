Article 707
----
Les trente ans commencent à courir, selon les diverses espèces de servitudes, ou
du jour où l'on a cessé d'en jouir, lorsqu'il s'agit de servitudes discontinues,
ou du jour où il a été fait un acte contraire à la servitude, lorsqu'il s'agit
de servitudes continues.
