Article 646
----
Tout propriétaire peut obliger son voisin au bornage de leurs propriétés
contiguës. Le bornage se fait à frais communs.
