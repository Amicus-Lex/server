Article 672
----
Le voisin peut exiger que les arbres, arbrisseaux et arbustes, plantés à une
distance moindre que la distance légale, soient arrachés ou réduits à la hauteur
déterminée dans l'article précédent, à moins qu'il n'y ait titre, destination du
père de famille ou prescription trentenaire.

Si les arbres meurent ou s'ils sont coupés ou arrachés, le voisin ne peut les
remplacer qu'en observant les distances légales.
