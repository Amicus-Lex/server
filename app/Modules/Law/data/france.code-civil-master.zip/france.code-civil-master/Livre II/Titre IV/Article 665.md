Article 665
----
Lorsqu'on reconstruit un mur mitoyen ou une maison, les servitudes actives et
passives se continuent à l'égard du nouveau mur ou de la nouvelle maison, sans
toutefois qu'elles puissent être aggravées, et pourvu que la reconstruction se
fasse avant que la prescription soit acquise.
