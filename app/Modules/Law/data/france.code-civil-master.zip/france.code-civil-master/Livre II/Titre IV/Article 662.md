Article 662
----
L'un des voisins ne peut pratiquer dans le corps d'un mur mitoyen aucun
enfoncement, ni y appliquer ou appuyer aucun ouvrage sans le consentement de
l'autre, ou sans avoir, à son refus, fait régler par experts les moyens
nécessaires pour que le nouvel ouvrage ne soit pas nuisible aux droits de
l'autre.
