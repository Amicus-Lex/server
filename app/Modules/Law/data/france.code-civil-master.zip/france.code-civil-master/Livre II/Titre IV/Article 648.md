Article 648
----
Le propriétaire qui veut se clore perd son droit au parcours et vaine pâture en
proportion du terrain qu'il y soustrait.
