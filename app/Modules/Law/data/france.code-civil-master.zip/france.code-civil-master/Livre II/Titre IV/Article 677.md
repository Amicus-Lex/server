Article 677
----
Ces fenêtres ou jours ne peuvent être établis qu'à vingt-six décimètres (huit
pieds) au-dessus du plancher ou sol de la chambre qu'on veut éclairer, si c'est
à rez-de-chaussée, et à dix-neuf décimètres (six pieds) au-dessus du plancher
pour les étages supérieurs.
