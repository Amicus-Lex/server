Article 709
----
Si l'héritage en faveur duquel la servitude est établie appartient à plusieurs
par indivis, la jouissance de l'un empêche la prescription à l'égard de tous.
