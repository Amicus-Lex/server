Article 681
----
Tout propriétaire doit établir des toits de manière que les eaux pluviales
s'écoulent sur son terrain ou sur la voie publique ; il ne peut les faire verser
sur le fonds de son voisin.
