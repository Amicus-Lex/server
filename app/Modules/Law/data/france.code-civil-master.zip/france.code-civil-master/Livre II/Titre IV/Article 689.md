Article 689
----
Les servitudes sont apparentes ou non apparentes.

Les servitudes apparentes sont celles qui s'annoncent par des ouvrages
extérieurs, tels qu'une porte, une fenêtre, un aqueduc.

Les servitudes non apparentes sont celles qui n'ont pas de signe extérieur de
leur existence, comme, par exemple, la prohibition de bâtir sur un fonds, ou de
ne bâtir qu'à une hauteur déterminée.
