Article 696
----
Quand on établit une servitude, on est censé accorder tout ce qui est nécessaire
pour en user.

Ainsi la servitude de puiser l'eau à la fontaine d'autrui emporte nécessairement
le droit de passage.
