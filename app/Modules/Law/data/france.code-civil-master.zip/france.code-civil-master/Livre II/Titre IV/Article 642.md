Article 642
----
Celui qui a une source dans son fonds peut toujours user des eaux à sa volonté
dans les limites et pour les besoins de son héritage.

Le propriétaire d'une source ne peut plus en user au préjudice des propriétaires
des fonds inférieurs qui, depuis plus de trente ans, ont fait et terminé, sur le
fonds où jaillit la source, des ouvrages apparents et permanents destinés à
utiliser les eaux ou à en faciliter le passage dans leur propriété.

Il ne peut pas non plus en user de manière à enlever aux habitants d'une
commune, village ou hameau, l'eau qui leur est nécessaire ; mais si les
habitants n'en n'ont pas acquis ou prescrit l'usage, le propriétaire peut
réclamer une indemnité, laquelle est réglée par experts.
