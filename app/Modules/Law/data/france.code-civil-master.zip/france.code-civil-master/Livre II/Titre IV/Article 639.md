Article 639
----
Elle dérive ou de la situation naturelle des lieux, ou des obligations imposées
par la loi, ou des conventions entre les propriétaires.
