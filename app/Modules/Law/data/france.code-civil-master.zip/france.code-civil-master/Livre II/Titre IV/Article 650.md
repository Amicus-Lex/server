Article 650
----
Celles établies pour l'utilité publique ou communale ont pour objet le
marchepied le long des cours d'eau domaniaux, la construction ou réparation des
chemins et autres ouvrages publics ou communaux.

Tout ce qui concerne cette espèce de servitude est déterminé par des lois ou des
règlements particuliers.
