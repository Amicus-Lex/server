Article 680
----
La distance dont il est parlé dans les deux articles précédents se compte depuis
le parement extérieur du mur où l'ouverture se fait, et, s'il y a balcons ou
autres semblables saillies, depuis leur ligne extérieure jusqu'à la ligne de
séparation des deux propriétés.
