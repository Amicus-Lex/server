Article 699
----
Dans le cas même où le propriétaire du fonds assujetti est chargé par le titre
de faire à ses frais les ouvrages nécessaires pour l'usage ou la conservation de
la servitude, il peut toujours s'affranchir de la charge, en abandonnant le
fonds assujetti au propriétaire du fonds auquel la servitude est due.
