Article 673
----
Celui sur la propriété duquel avancent les branches des arbres, arbustes et
arbrisseaux du voisin peut contraindre celui-ci à les couper. Les fruits tombés
naturellement de ces branches lui appartiennent.

Si ce sont les racines, ronces ou brindilles qui avancent sur son héritage, il a
le droit de les couper lui-même à la limite de la ligne séparative.

Le droit de couper les racines, ronces et brindilles ou de faire couper les
branches des arbres, arbustes ou arbrisseaux est imprescriptible.
