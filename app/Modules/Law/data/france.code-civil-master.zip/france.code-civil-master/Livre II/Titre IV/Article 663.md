Article 663
----
Chacun peut contraindre son voisin, dans les villes et faubourgs, à contribuer
aux constructions et réparations de la clôture faisant séparation de leurs
maisons, cours et jardins assis ès dites villes et faubourgs : la hauteur de la
clôture sera fixée suivant les règlements particuliers ou les usages constants
et reconnus et, à défaut d'usages et de règlements, tout mur de séparation entre
voisins, qui sera construit ou rétabli à l'avenir, doit avoir au moins trente-
deux décimètres de hauteur, compris le chaperon, dans les villes de cinquante
mille âmes et au-dessus, et vingt-six décimètres dans les autres.
