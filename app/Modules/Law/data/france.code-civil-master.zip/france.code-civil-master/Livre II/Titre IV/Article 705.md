Article 705
----
Toute servitude est éteinte lorsque le fonds à qui elle est due, et celui qui la
doit, sont réunis dans la même main.
