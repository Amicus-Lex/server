Article 515-14
----
Les animaux sont des êtres vivants doués de sensibilité. Sous réserve des lois
qui les protègent, les animaux sont soumis au régime des biens.
