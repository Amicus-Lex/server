Article 616
----
Si le troupeau sur lequel un usufruit a été établi périt entièrement par
accident ou par maladie et sans la faute de l'usufruitier, celui-ci n'est tenu
envers le propriétaire que de lui rendre compte des cuirs, ou de leur valeur
estimée à la date de la restitution.

Si le troupeau ne périt pas entièrement, l'usufruitier est tenu de remplacer,
jusqu'à concurrence du croît, les têtes des animaux qui ont péri.
