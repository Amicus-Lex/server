Article 628
----
Les droits d'usage et d'habitation se règlent par le titre qui les a établis et
reçoivent, d'après ses dispositions, plus ou moins d'étendue.
