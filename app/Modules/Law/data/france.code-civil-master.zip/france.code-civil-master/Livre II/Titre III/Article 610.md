Article 610
----
Le legs fait par un testateur, d'une rente viagère ou pension alimentaire, doit
être acquitté par le légataire universel de l'usufruit dans son intégrité, et
par le légataire à titre universel de l'usufruit dans la proportion de sa
jouissance, sans aucune répétition de leur part.
