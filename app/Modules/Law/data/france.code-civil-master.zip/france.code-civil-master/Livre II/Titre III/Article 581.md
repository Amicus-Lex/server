Article 581
----
Il peut être établi sur toute espèce de biens meubles ou immeubles.
