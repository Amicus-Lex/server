Article 601
----
Il donne caution de jouir raisonnablement, s'il n'en est dispensé par l'acte
constitutif de l'usufruit ; cependant les père et mère ayant l'usufruit légal du
bien de leurs enfants, le vendeur ou le donateur, sous réserve d'usufruit, ne
sont pas tenus de donner caution.
