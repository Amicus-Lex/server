Article 617
----
L'usufruit s'éteint :

Par la mort de l'usufruitier ;

Par l'expiration du temps pour lequel il a été accordé ;

Par la consolidation ou la réunion sur la même tête, des deux qualités
d'usufruitier et de propriétaire ;

Par le non-usage du droit pendant trente ans ;

Par la perte totale de la chose sur laquelle l'usufruit est établi.
