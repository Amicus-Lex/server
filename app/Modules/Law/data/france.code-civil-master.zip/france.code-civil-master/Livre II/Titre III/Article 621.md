Article 621
----
En cas de vente simultanée de l'usufruit et de la nue-propriété d'un bien, le
prix se répartit entre l'usufruit et la nue-propriété selon la valeur respective
de chacun de ces droits, sauf accord des parties pour reporter l'usufruit sur le
prix.

La vente du bien grevé d'usufruit, sans l'accord de l'usufruitier, ne modifie
pas le droit de ce dernier, qui continue à jouir de son usufruit sur le bien
s'il n'y a pas expressément renoncé.
