Article 592
----
Dans tous les autres cas, l'usufruitier ne peut toucher aux arbres de haute
futaie : il peut seulement employer, pour faire les réparations dont il est
tenu, les arbres arrachés ou brisés par accident ; il peut même, pour cet objet,
en faire abattre s'il est nécessaire, mais à la charge d'en faire constater la
nécessité avec le propriétaire.
