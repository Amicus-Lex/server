Article 584
----
Les fruits civils sont les loyers des maisons, les intérêts des sommes
exigibles, les arrérages des rentes.

Les prix des baux à ferme sont aussi rangés dans la classe des fruits civils.
