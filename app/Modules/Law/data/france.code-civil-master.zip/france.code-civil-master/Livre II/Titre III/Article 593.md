Article 593
----
Il peut prendre, dans les bois, des échalas pour les vignes ; il peut aussi
prendre, sur les arbres, des produits annuels ou périodiques ; le tout suivant
l'usage du pays ou la coutume des propriétaires.
