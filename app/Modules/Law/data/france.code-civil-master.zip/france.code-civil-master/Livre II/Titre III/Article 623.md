Article 623
----
Si une partie seulement de la chose soumise à l'usufruit est détruite,
l'usufruit se conserve sur ce qui reste.
