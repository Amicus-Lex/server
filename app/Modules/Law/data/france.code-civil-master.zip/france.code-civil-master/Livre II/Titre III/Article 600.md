Article 600
----
L'usufruitier prend les choses dans l'état où elles sont, mais il ne peut entrer
en jouissance qu'après avoir fait dresser, en présence du propriétaire, ou lui
dûment appelé, un inventaire des meubles et un état des immeubles sujets à
l'usufruit.
