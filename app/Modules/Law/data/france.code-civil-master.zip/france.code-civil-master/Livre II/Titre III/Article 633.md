Article 633
----
Le droit d'habitation se restreint à ce qui est nécessaire pour l'habitation de
celui à qui ce droit est concédé et de sa famille.
