Article 624
----
Si l'usufruit n'est établi que sur un bâtiment, et que ce bâtiment soit détruit
par un incendie ou autre accident, ou qu'il s'écroule de vétusté, l'usufruitier
n'aura le droit de jouir ni du sol ni des matériaux.

Si l'usufruit était établi sur un domaine dont le bâtiment faisait partie,
l'usufruitier jouirait du sol et des matériaux.
