Article 611
----
L'usufruitier à titre particulier n'est pas tenu des dettes auxquelles le fonds
est hypothéqué : s'il est forcé de les payer, il a son recours contre le
propriétaire, sauf ce qui est dit à l'article 1020, au titre " Des donations
entre vifs et des testaments ".
