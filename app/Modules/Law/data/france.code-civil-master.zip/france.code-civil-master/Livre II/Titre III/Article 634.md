Article 634
----
Le droit d'habitation ne peut être ni cédé ni loué.
