Article 625
----
Les droits d'usage et d'habitation s'établissent et se perdent de la même
manière que l'usufruit.
