Article 622
----
Les créanciers de l'usufruitier peuvent faire annuler la renonciation qu'il
aurait faite à leur préjudice.
