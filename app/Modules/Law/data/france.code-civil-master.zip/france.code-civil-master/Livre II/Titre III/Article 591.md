Article 591
----
L'usufruitier profite encore, toujours en se conformant aux époques et à l'usage
des anciens propriétaires, des parties de bois de haute futaie qui ont été mises
en coupes réglées, soit que ces coupes se fassent périodiquement sur une
certaine étendue de terrain, soit qu'elles se fassent d'une certaine quantité
d'arbres pris indistinctement sur toute la surface du domaine.
