Article 604
----
Le retard de donner caution ne prive pas l'usufruitier des fruits auxquels il
peut avoir droit ; ils lui sont dus du moment où l'usufruit a été ouvert.
