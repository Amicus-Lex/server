Article 598
----
Il jouit aussi, de la même manière que le propriétaire, des mines et carrières
qui sont en exploitation à l'ouverture de l'usufruit ; et néanmoins, s'il s'agit
d'une exploitation qui ne puisse être faite sans une concession, l'usufruitier
ne pourra en jouir qu'après en avoir obtenu la permission du Président de la
République.

Il n'a aucun droit aux mines et carrières non encore ouvertes, ni aux tourbières
dont l'exploitation n'est point encore commencée, ni au trésor qui pourrait être
découvert pendant la durée de l'usufruit.
