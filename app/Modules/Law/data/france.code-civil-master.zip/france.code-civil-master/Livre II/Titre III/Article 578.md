Article 578
----
L'usufruit est le droit de jouir des choses dont un autre a la propriété, comme
le propriétaire lui-même, mais à la charge d'en conserver la substance.
