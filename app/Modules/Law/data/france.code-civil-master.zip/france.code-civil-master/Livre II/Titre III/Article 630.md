Article 630
----
Celui qui a l'usage des fruits d'un fonds ne peut en exiger qu'autant qu'il lui
en faut pour ses besoins et ceux de sa famille.

Il peut en exiger pour les besoins même des enfants qui lui sont survenus depuis
la concession de l'usage.
