Article 583
----
Les fruits naturels sont ceux qui sont le produit spontané de la terre. Le
produit et le croît des animaux sont aussi des fruits naturels.

Les fruits industriels d'un fonds sont ceux qu'on obtient par la culture.
