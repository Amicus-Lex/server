Article 620
----
L'usufruit accordé jusqu'à ce qu'un tiers ait atteint un âge fixe dure jusqu'à
cette époque, encore que le tiers soit mort avant l'âge fixé.
