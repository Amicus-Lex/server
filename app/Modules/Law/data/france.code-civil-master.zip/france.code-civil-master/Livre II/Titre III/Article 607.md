Article 607
----
Ni le propriétaire, ni l'usufruitier, ne sont tenus de rebâtir ce qui est tombé
de vétusté, ou ce qui a été détruit par cas fortuit.
