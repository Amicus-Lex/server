Article 635
----
Si l'usager absorbe tous les fruits du fonds ou s'il occupe la totalité de la
maison, il est assujetti aux frais de culture, aux réparations d'entretien et au
paiement des contributions, comme l'usufruitier.

S'il ne prend qu'une partie des fruits ou s'il n'occupe qu'une partie de la
maison, il contribue au prorata de ce dont il jouit.
