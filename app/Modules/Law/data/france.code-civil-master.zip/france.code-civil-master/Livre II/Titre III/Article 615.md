Article 615
----
Si l'usufruit n'est établi que sur un animal qui vient à périr sans la faute de
l'usufruitier, celui-ci n'est pas tenu d'en rendre un autre, ni d'en payer
l'estimation.
