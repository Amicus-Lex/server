Article 582
----
L'usufruitier a le droit de jouir de toute espèce de fruits, soit naturels, soit
industriels, soit civils, que peut produire l'objet dont il a l'usufruit.
