Article 606
----
Les grosses réparations sont celles des gros murs et des voûtes, le
rétablissement des poutres et des couvertures entières.

Celui des digues et des murs de soutènement et de clôture aussi en entier.

Toutes les autres réparations sont d'entretien.
