Article 632
----
Celui qui a un droit d'habitation dans une maison peut y demeurer avec sa
famille, quand même il n'aurait pas été marié à l'époque où ce droit lui a été
donné.
