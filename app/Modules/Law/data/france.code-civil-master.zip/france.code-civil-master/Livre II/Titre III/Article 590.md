Article 590
----
Si l'usufruit comprend des bois taillis, l'usufruitier est tenu d'observer
l'ordre et la quotité des coupes, conformément à l'aménagement ou à l'usage
constant des propriétaires ; sans indemnité toutefois en faveur de l'usufruitier
ou de ses héritiers, pour les coupes ordinaires, soit de taillis, soit de
baliveaux, soit de futaie, qu'il n'aurait pas faites pendant sa jouissance.

Les arbres qu'on peut tirer d'une pépinière sans la dégrader ne font aussi
partie de l'usufruit qu'à la charge par l'usufruitier de se conformer aux usages
des lieux pour le remplacement.
