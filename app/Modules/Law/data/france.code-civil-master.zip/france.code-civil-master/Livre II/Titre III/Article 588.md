Article 588
----
L'usufruit d'une rente viagère donne aussi à l'usufruitier, pendant la durée de
son usufruit, le droit d'en percevoir les arrérages, sans être tenu à aucune
restitution.
