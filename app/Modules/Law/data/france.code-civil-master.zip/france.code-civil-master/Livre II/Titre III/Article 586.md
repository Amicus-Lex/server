Article 586
----
Les fruits civils sont réputés s'acquérir jour par jour et appartiennent à
l'usufruitier à proportion de la durée de son usufruit. Cette règle s'applique
aux prix des baux à ferme comme aux loyers des maisons et autres fruits civils.
