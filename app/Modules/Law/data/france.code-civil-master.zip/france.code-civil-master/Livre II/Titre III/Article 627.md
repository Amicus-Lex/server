Article 627
----
L'usager, et celui qui a un droit d'habitation, doivent jouir raisonnablement.
