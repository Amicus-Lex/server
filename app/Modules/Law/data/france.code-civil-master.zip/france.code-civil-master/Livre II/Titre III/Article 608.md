Article 608
----
L'usufruitier est tenu, pendant sa jouissance, de toutes les charges annuelles
de l'héritage, telles que les contributions et autres qui dans l'usage sont
censées charges des fruits.
