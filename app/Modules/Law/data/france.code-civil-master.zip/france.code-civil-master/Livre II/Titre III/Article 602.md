Article 602
----
Si l'usufruitier ne trouve pas de caution, les immeubles sont donnés à ferme ou
mis en séquestre ;

Les sommes comprises dans l'usufruit sont placées ;

Les denrées sont vendues et le prix en provenant est pareillement placé ;

Les intérêts de ces sommes et les prix des fermes appartiennent, dans ce cas, à
l'usufruitier.
