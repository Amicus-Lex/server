Article 605
----
L'usufruitier n'est tenu qu'aux réparations d'entretien.

Les grosses réparations demeurent à la charge du propriétaire, à moins qu'elles
n'aient été occasionnées par le défaut de réparations d'entretien, depuis
l'ouverture de l'usufruit ; auquel cas l'usufruitier en est aussi tenu.
