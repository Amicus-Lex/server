Article 614
----
Si, pendant la durée de l'usufruit, un tiers commet quelque usurpation sur le
fonds, ou attente autrement aux droits du propriétaire, l'usufruitier est tenu
de le dénoncer à celui-ci ; faute de ce, il est responsable de tout le dommage
qui peut en résulter pour le propriétaire, comme il le serait de dégradations
commises par lui-même.
