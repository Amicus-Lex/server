Article 594
----
Les arbres fruitiers qui meurent, ceux mêmes qui sont arrachés ou brisés par
accident, appartiennent à l'usufruitier, à la charge de les remplacer par
d'autres.
