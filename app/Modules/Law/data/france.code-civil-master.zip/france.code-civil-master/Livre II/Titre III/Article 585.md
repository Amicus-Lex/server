Article 585
----
Les fruits naturels et industriels, pendants par branches ou par racines au
moment où l'usufruit est ouvert, appartiennent à l'usufruitier.

Ceux qui sont dans le même état au moment où finit l'usufruit appartiennent au
propriétaire, sans récompense de part ni d'autre des labours et des semences,
mais aussi sans préjudice de la portion des fruits qui pourrait être acquise au
métayer, s'il en existait un au commencement ou à la cessation de l'usufruit.
