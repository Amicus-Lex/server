Article 613
----
L'usufruitier n'est tenu que des frais des procès qui concernent la jouissance
et des autres condamnations auxquelles ces procès pourraient donner lieu.
