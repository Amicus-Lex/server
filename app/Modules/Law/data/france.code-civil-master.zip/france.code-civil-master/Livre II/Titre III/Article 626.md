Article 626
----
On ne peut en jouir, comme dans le cas de l'usufruit, sans donner préalablement
caution et sans faire des états et inventaires.
