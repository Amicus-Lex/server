Article 618
----
L'usufruit peut aussi cesser par l'abus que l'usufruitier fait de sa jouissance,
soit en commettant des dégradations sur le fonds, soit en le laissant dépérir
faute d'entretien.

Les créanciers de l'usufruitier peuvent intervenir dans les contestations pour
la conservation de leurs droits ; ils peuvent offrir la réparation des
dégradations commises et des garanties pour l'avenir.

Les juges peuvent, suivant la gravité des circonstances, ou prononcer
l'extinction absolue de l'usufruit, ou n'ordonner la rentrée du propriétaire
dans la jouissance de l'objet qui en est grevé, que sous la charge de payer
annuellement à l'usufruitier, ou à ses ayants cause, une somme déterminée,
jusqu'à l'instant où l'usufruit aurait dû cesser.
