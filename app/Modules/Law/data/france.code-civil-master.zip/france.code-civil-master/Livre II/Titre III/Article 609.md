Article 609
----
A l'égard des charges qui peuvent être imposées sur la propriété pendant la
durée de l'usufruit, l'usufruitier et le propriétaire y contribuent ainsi qu'il
suit :

Le propriétaire est obligé de les payer, et l'usufruitier doit lui tenir compte
des intérêts ;

Si elles sont avancées par l'usufruitier, il a la répétition du capital à la fin
de l'usufruit.
