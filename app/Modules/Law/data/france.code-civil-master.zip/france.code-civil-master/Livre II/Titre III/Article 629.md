Article 629
----
Si le titre ne s'explique pas sur l'étendue de ces droits ils sont réglés ainsi
qu'il suit.
