Article 631
----
L'usager ne peut céder ni louer son droit à un autre.
