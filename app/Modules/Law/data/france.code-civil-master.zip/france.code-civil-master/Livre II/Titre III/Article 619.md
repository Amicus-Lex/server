Article 619
----
L'usufruit qui n'est pas accordé à des particuliers ne dure que trente ans.
