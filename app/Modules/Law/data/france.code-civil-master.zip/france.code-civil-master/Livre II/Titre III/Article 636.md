Article 636
----
L'usage des bois et forêts est réglé par des lois particulières.
