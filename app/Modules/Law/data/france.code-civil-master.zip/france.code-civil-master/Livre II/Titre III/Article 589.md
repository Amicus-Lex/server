Article 589
----
Si l'usufruit comprend des choses qui, sans se consommer de suite, se
détériorent peu à peu par l'usage, comme du linge, des meubles meublants,
l'usufruitier a le droit de s'en servir pour l'usage auquel elles sont
destinées, et n'est obligé de les rendre à la fin de l'usufruit que dans l'état
où elles se trouvent, non détériorées par son dol ou par sa faute.
