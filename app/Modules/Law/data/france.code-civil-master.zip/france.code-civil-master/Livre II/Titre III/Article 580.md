Article 580
----
L'usufruit peut être établi, ou purement, ou à certain jour, ou à condition.
