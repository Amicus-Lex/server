Article 597
----
Il jouit des droits de servitude, de passage, et généralement de tous les droits
dont le propriétaire peut jouir, et il en jouit comme le propriétaire lui-même.
