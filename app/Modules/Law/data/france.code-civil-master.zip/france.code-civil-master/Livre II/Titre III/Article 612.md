Article 612
----
L'usufruitier, ou universel, ou à titre universel, doit contribuer avec le
propriétaire au paiement des dettes ainsi qu'il suit :

On estime la valeur du fonds sujet à usufruit ; on fixe ensuite la contribution
aux dettes à raison de cette valeur.

Si l'usufruitier veut avancer la somme pour laquelle le fonds doit contribuer,
le capital lui en est restitué à la fin de l'usufruit, sans aucun intérêt.

Si l'usufruitier ne veut pas faire cette avance, le propriétaire a le choix, ou
de payer cette somme, et, dans ce cas, l'usufruitier lui tient compte des
intérêts pendant la durée de l'usufruit, ou de faire vendre jusqu'à due
concurrence une portion des biens soumis à l'usufruit.
