Article 579
----
L'usufruit est établi par la loi, ou par la volonté de l'homme.
