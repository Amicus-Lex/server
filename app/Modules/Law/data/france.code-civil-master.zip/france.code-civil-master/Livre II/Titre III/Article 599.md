Article 599
----
Le propriétaire ne peut, par son fait, ni de quelque manière que ce soit, nuire
aux droits de l'usufruitier.

De son côté, l'usufruitier ne peut, à la cessation de l'usufruit, réclamer
aucune indemnité pour les améliorations qu'il prétendrait avoir faites, encore
que la valeur de la chose en fût augmentée.

Il peut cependant, ou ses héritiers, enlever les glaces, tableaux et autres
ornements qu'il aurait fait placer, mais à la charge de rétablir les lieux dans
leur premier état.
