Article 603
----
A défaut d'une caution de la part de l'usufruitier, le propriétaire peut exiger
que les meubles qui dépérissent par l'usage soient vendus, pour le prix en être
placé comme celui des denrées ; et alors l'usufruitier jouit de l'intérêt
pendant son usufruit : cependant l'usufruitier pourra demander, et les juges
pourront ordonner, suivant les circonstances, qu'une partie des meubles
nécessaires pour son usage lui soit délaissée, sous sa simple caution juratoire,
et à la charge de les représenter à l'extinction de l'usufruit.
