Article 596
----
L'usufruitier jouit de l'augmentation survenue par alluvion à l'objet dont il a
l'usufruit.
