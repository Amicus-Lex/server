Article 587
----
Si l'usufruit comprend des choses dont on ne peut faire usage sans les
consommer, comme l'argent, les grains, les liqueurs, l'usufruitier a le droit de
s'en servir, mais à la charge de rendre, à la fin de l'usufruit, soit des choses
de même quantité et qualité soit leur valeur estimée à la date de la
restitution.
