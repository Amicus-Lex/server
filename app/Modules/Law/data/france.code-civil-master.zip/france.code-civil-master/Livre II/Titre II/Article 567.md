Article 567
----
Est réputée partie principale celle à laquelle l'autre n'a été unie que pour
l'usage, l'ornement ou le complément de la première.
