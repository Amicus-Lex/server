Article 545
----
Nul ne peut être contraint de céder sa propriété, si ce n'est pour cause
d'utilité publique, et moyennant une juste et préalable indemnité.
