Article 551
----
Tout ce qui s'unit et s'incorpore à la chose appartient au propriétaire, suivant
les règles qui seront ci-après établies.
