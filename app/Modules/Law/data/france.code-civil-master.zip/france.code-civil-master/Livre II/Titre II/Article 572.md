Article 572
----
Lorsqu'une personne a employé en partie la matière qui lui appartenait et en
partie celle qui ne lui appartenait pas à former une chose d'une espèce
nouvelle, sans que ni l'une ni l'autre des deux matières soit entièrement
détruite, mais de manière qu'elles ne puissent pas se séparer sans inconvénient,
la chose est commune aux deux propriétaires, en raison, quant à l'un, de la
matière qui lui appartenait, quant à l'autre, en raison à la fois et de la
matière qui lui appartenait et du prix de sa main-d'oeuvre. Le prix de la
main-d'oeuvre est estimé à la date de la licitation prévue à l'article 575.
