Article 553
----
Toutes constructions, plantations et ouvrages sur un terrain ou dans l'intérieur
sont présumés faits par le propriétaire à ses frais et lui appartenir, si le
contraire n'est prouvé ; sans préjudice de la propriété qu'un tiers pourrait
avoir acquise ou pourrait acquérir par prescription soit d'un souterrain sous le
bâtiment d'autrui, soit de toute autre partie du bâtiment.
