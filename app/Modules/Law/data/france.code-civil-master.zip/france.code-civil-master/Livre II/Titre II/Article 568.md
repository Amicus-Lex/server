Article 568
----
Néanmoins, quand la chose unie est beaucoup plus précieuse que la chose
principale, et quand elle a été employée à l'insu du propriétaire, celui-ci peut
demander que la chose unie soit séparée pour lui être rendue, même quand il
pourrait en résulter quelque dégradation de la chose à laquelle elle a été
jointe.
