Article 549
----
Le simple possesseur ne fait les fruits siens que dans le cas où il possède de
bonne foi. Dans le cas contraire, il est tenu de restituer les produits avec la
chose au propriétaire qui la revendique ; si lesdits produits ne se retrouvent
pas en nature, leur valeur est estimée à la date du remboursement.
