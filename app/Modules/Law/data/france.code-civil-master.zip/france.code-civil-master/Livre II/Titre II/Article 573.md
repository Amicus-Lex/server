Article 573
----
Lorsqu'une chose a été formée par le mélange de plusieurs matières appartenant à
différents propriétaires, mais dont aucune ne peut être regardée comme la
matière principale, si les matières peuvent être séparées, celui à l'insu duquel
les matières ont été mélangées peut en demander la division.

Si les matières ne peuvent plus être séparées sans inconvénient, ils en
acquièrent en commun la propriété dans la proportion de la quantité, de la
qualité et de la valeur des matières appartenant à chacun d'eux.
