Article 574
----
Si la matière appartenant à l'un des propriétaires était de beaucoup supérieure
à l'autre par la quantité et le prix, en ce cas le propriétaire de la matière
supérieure en valeur pourrait réclamer la chose provenue du mélange en
remboursant à l'autre la valeur de sa matière, estimée à la date du
remboursement.
