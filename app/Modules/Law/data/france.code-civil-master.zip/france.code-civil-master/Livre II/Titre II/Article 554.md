Article 554
----
Le propriétaire du sol qui a fait des constructions, plantations et ouvrages
avec des matériaux qui ne lui appartenaient pas doit en payer la valeur estimée
à la date du paiement ; il peut aussi être condamné à des dommages-intérêts,
s'il ya lieu : mais le propriétaire des matériaux n'a pas le droit de les
enlever.
