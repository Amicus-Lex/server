Article 558
----
L'alluvion n'a pas lieu à l'égard des lacs et étangs, dont le propriétaire
conserve toujours le terrain que l'eau couvre quand elle est à la hauteur de la
décharge de l'étang, encore que le volume de l'eau vienne à diminuer.

Réciproquement, le propriétaire de l'étang n'acquiert aucun droit sur les terres
riveraines que son eau vient à couvrir dans des crues extraordinaires.
