Article 556
----
Les atterrissements et accroissements qui se forment successivement et
imperceptiblement aux fonds riverains d'un cours d'eau s'appellent "alluvion".

L'alluvion profite au propriétaire riverain, qu'il s'agisse d'un cours d'eau
domanial ou non ; à la charge, dans le premier cas, de laisser le marchepied ou
chemin de halage, conformément aux règlements.
