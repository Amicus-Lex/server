Article 555
----
Lorsque les plantations, constructions et ouvrages ont été faits par un tiers et
avec des matériaux appartenant à ce dernier, le propriétaire du fonds a le
droit, sous réserve des dispositions de l'alinéa 4, soit d'en conserver la
propriété, soit d'obliger le tiers à les enlever.

Si le propriétaire du fonds exige la suppression des constructions, plantations
et ouvrages, elle est exécutée aux frais du tiers, sans aucune indemnité pour
lui ; le tiers peut, en outre, être condamné à des dommages-intérêts pour le
préjudice éventuellement subi par le propriétaire du fonds.

Si le propriétaire du fonds préfère conserver la propriété des constructions,
plantations et ouvrages, il doit, à son choix, rembourser au tiers, soit une
somme égale à celle dont le fonds a augmenté de valeur, soit le coût des
matériaux et le prix de la main-d'oeuvre estimés à la date du remboursement,
compte tenu de l'état dans lequel se trouvent lesdites constructions,
plantations et ouvrages.

Si les plantations, constructions et ouvrages ont été faits par un tiers évincé
qui n'aurait pas été condamné, en raison de sa bonne foi, à la restitution des
fruits, le propriétaire ne pourra exiger la suppression desdits ouvrages,
constructions et plantations, mais il aura le choix de rembourser au tiers l'une
ou l'autre des sommes visées à l'alinéa précédent.
