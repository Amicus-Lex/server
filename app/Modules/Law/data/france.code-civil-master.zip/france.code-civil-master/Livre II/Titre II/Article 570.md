Article 570
----
Si un artisan ou une personne quelconque a employé une matière qui ne lui
appartenait pas à former une chose d'une nouvelle espèce, soit que la matière
puisse ou non reprendre sa première forme, celui qui en était le propriétaire a
le droit de réclamer la chose qui en a été formée en remboursant le prix de la
main-d'oeuvre estimée à la date du remboursement.
