Article 563
----
Si un cours d'eau domanial forme un nouveau cours en abandonnant son ancien lit,
les propriétaires riverains peuvent acquérir la propriété de cet ancien lit,
chacun en droit soi, jusqu'à une ligne qu'on suppose tracée au milieu du cours
d'eau. Le prix de l'ancien lit est fixé par des experts nommés par le président
du tribunal de la situation des lieux, à la requête de l'autorité compétente.

A défaut par les propriétaires riverains de déclarer, dans les trois mois de la
notification qui leur sera faite par l'autorité compétente, l'intention de faire
l'acquisition aux prix fixés par les experts, il est procédé à l'aliénation de
l'ancien lit selon les règles qui président aux aliénations du domaine des
personnes publiques.

Le prix provenant de la vente est distribué aux propriétaires des fonds occupés
par le nouveau cours à titre d'indemnité, dans la proportion de la valeur du
terrain enlevé à chacun d'eux.
