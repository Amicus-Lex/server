Article 562
----
Si un cours d'eau, en se formant un bras nouveau, coupe et embrasse le champ
d'un propriétaire riverain, et en fait une île, ce propriétaire conserve la
propriété de son champ, encore que l'île se soit formée dans un cours d'eau
domanial.
