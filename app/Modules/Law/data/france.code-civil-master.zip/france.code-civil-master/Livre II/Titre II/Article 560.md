Article 560
----
Les îles, îlots, atterrissements, qui se forment dans le lit des cours d'eau
domaniaux, appartiennent à la personne publique propriétaire du domaine
concerné, en l'absence de titre ou de prescription contraire.
