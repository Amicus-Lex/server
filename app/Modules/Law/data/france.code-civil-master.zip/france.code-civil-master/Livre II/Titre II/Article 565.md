Article 565
----
Le droit d'accession, quand il a pour objet deux choses mobilières appartenant à
deux maîtres différents, est entièrement subordonné aux principes de l'équité
naturelle.

Les règles suivantes serviront d'exemple au juge pour se déterminer, dans les
cas non prévus, suivant les circonstances particulières.
