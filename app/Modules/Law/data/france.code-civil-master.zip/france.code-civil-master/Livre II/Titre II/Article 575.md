Article 575
----
Lorsque la chose reste en commun entre les propriétaires des matières dont elle
a été formée, elle doit être licitée au profit commun.
