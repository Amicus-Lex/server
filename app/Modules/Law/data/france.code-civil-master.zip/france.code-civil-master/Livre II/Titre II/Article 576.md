Article 576
----
Dans tous les cas où le propriétaire dont la matière a été employée, à son insu,
à former une chose d'une autre espèce peut réclamer la propriété de cette chose,
il a le choix de demander la restitution de sa matière en même nature, quantité,
poids, mesure et bonté, ou sa valeur estimée à la date de la restitution.
