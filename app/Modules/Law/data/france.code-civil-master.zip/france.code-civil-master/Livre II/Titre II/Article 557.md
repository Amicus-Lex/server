Article 557
----
Il en est de même des relais que forme l'eau courante qui se retire
insensiblement de l'une de ses rives en se portant sur l'autre : le propriétaire
de la rive découverte profite de l'alluvion, sans que le riverain du côté opposé
y puisse venir réclamer le terrain qu'il a perdu.

Ce droit n'a pas lieu à l'égard des relais de la mer.
