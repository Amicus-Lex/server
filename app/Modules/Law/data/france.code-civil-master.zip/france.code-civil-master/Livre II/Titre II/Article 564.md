Article 564
----
Les pigeons, lapins, poissons, qui passent dans un autre colombier, garenne ou
plan d'eau visé aux articles L. 431-6 et L. 431-7 du code de l'environnement
appartiennent au propriétaire de ces derniers, pourvu qu'ils n'y aient point été
attirés par fraude et artifice.
