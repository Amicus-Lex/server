Article 550
----
Le possesseur est de bonne foi quand il possède comme propriétaire, en vertu
d'un titre translatif de propriété dont il ignore les vices.

Il cesse d'être de bonne foi du moment où ces vices lui sont connus.
