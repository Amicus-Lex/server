Article 552
----
La propriété du sol emporte la propriété du dessus et du dessous.

Le propriétaire peut faire au-dessus toutes les plantations et constructions
qu'il juge à propos, sauf les exceptions établies au titre "Des servitudes ou
services fonciers".

Il peut faire au-dessous toutes les constructions et fouilles qu'il jugera à
propos, et tirer de ces fouilles tous les produits qu'elles peuvent fournir,
sauf les modifications résultant des lois et règlements relatifs aux mines, et
des lois et règlements de police.
