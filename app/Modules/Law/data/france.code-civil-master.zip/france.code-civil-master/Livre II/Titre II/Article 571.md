Article 571
----
Si, cependant, la main-d'oeuvre était tellement importante qu'elle surpassât de
beaucoup la valeur de la matière employée, l'industrie serait alors réputée la
partie principale, et l'ouvrier aurait le droit de retenir la chose travaillée,
en remboursant au propriétaire le prix de la matière, estimée à la date du
remboursement.
