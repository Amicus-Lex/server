Article 561
----
Les îles et atterrissements qui se forment dans les cours d'eau non domaniaux,
appartiennent aux propriétaires riverains du côté où l'île s'est formée : si
l'île n'est pas formée d'un seul côté, elle appartient aux propriétaires
riverains des deux côtés, à partir de la ligne qu'on suppose tracée au milieu du
cours d'eau.
