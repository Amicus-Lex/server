Article 577
----
Ceux qui auront employé des matières appartenant à d'autres, et à leur insu,
pourront aussi être condamnés à des dommages et intérêts, s'il y a lieu, sans
préjudice des poursuites par voie extraordinaire, si le cas y échet.
