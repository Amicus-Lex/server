Article 544
----
La propriété est le droit de jouir et disposer des choses de la manière la plus
absolue, pourvu qu'on n'en fasse pas un usage prohibé par les lois ou par les
règlements.
