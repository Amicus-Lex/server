Article 548
----
Les fruits produits par la chose n'appartiennent au propriétaire qu'à la charge
de rembourser les frais des labours, travaux et semences faits par des tiers et
dont la valeur est estimée à la date du remboursement.
