Article 559
----
Si un cours d'eau, domanial ou non, enlève par une force subite une partie
considérable et reconnaissable d'un champ riverain, et la porte vers un champ
inférieur ou sur la rive opposée, le propriétaire de la partie enlevée peut
réclamer sa propriété ; mais il est tenu de former sa demande dans l'année :
après ce délai, il n'y sera plus recevable, à moins que le propriétaire du champ
auquel la partie enlevée a été unie, n'eût pas encore pris possession de celle-
ci.
