Article 547
----
Les fruits naturels ou industriels de la terre,

Les fruits civils,

Le croît des animaux, appartiennent au propriétaire par droit d'accession.
