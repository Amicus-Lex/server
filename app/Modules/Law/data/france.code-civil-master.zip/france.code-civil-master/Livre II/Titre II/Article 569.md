Article 569
----
Si de deux choses unies pour former un seul tout, l'une ne peut point être
regardée comme l'accessoire de l'autre, celle-là est réputée principale qui est
la plus considérable en valeur, ou en volume, si les valeurs sont à peu près
égales.
