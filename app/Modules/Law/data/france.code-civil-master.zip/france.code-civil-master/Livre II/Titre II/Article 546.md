Article 546
----
La propriété d'une chose soit mobilière, soit immobilière, donne droit sur tout
ce qu'elle produit, et sur ce qui s'y unit accessoirement soit naturellement,
soit artificiellement.

Ce droit s'appelle "droit d'accession".
