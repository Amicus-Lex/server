Article 566
----
Lorsque deux choses appartenant à différents maîtres, qui ont été unies de
manière à former un tout, sont néanmoins séparables, en sorte que l'une puisse
subsister sans l'autre, le tout appartient au maître de la chose qui forme la
partie principale, à la charge de payer à l'autre la valeur, estimée à la date
du paiement, de la chose qui a été unie.
