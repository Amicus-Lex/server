Article 534
----
Les mots "meubles meublants" ne comprennent que les meubles destinés à l'usage
et à l'ornement des appartements, comme tapisseries, lits, sièges, glaces,
pendules, tables, porcelaines et autres objets de cette nature.

Les tableaux et les statues qui font partie du meuble d'un appartement y sont
aussi compris, mais non les collections de tableaux qui peuvent être dans les
galeries ou pièces particulières.

Il en est de même des porcelaines : celles seulement qui font partie de la
décoration d'un appartement sont comprises sous la dénomination de "meubles
meublants".
