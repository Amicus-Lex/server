Article 537
----
Les particuliers ont la libre disposition des biens qui leur appartiennent, sous
les modifications établies par les lois.

Les biens qui n'appartiennent pas à des particuliers sont administrés et ne
peuvent être aliénés que dans les formes et suivant les règles qui leur sont
particulières.
