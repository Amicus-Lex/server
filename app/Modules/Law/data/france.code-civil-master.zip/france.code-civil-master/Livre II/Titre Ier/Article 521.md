Article 521
----
Les coupes ordinaires des bois taillis ou de futaies mises en coupes réglées ne
deviennent meubles qu'au fur et à mesure que les arbres sont abattus.
