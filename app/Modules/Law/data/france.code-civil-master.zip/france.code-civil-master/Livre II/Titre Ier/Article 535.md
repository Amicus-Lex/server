Article 535
----
L'expression "biens meubles", celle de "mobilier ou d'effets mobiliers",
comprennent généralement tout ce qui est censé meuble d'après les règles ci-
dessus établies.

La vente ou le don d'une maison meublée ne comprend que les meubles meublants.
