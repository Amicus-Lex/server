Article 520
----
Les récoltes pendantes par les racines et les fruits des arbres non encore
recueillis sont pareillement immeubles.

Dès que les grains sont coupés et les fruits détachés, quoique non enlevés, ils
sont meubles.

Si une partie seulement de la récolte est coupée, cette partie seule est meuble.
