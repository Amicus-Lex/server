Article 523
----
Les tuyaux servant à la conduite des eaux dans une maison ou autre héritage sont
immeubles et font partie du fonds auquel ils sont attachés.
