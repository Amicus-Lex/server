Article 525
----
Le propriétaire est censé avoir attaché à son fonds des effets mobiliers à
perpétuelle demeure, quand ils y sont scellés en plâtre ou à chaux ou à ciment,
ou, lorsqu'ils ne peuvent être détachés sans être fracturés ou détériorés, ou
sans briser ou détériorer la partie du fonds à laquelle ils sont attachés.

Les glaces d'un appartement sont censées mises à perpétuelle demeure lorsque le
parquet sur lequel elles sont attachées fait corps avec la boiserie.

Il en est de même des tableaux et autres ornements.

Quant aux statues, elles sont immeubles lorsqu'elles sont placées dans une niche
pratiquée exprès pour les recevoir, encore qu'elles puissent être enlevées sans
fracture ou détérioration.
