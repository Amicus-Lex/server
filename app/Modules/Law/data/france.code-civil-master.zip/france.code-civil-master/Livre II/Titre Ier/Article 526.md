Article 526
----
Sont immeubles, par l'objet auquel ils s'appliquent :

L'usufruit des choses immobilières ;

Les servitudes ou services fonciers ;

Les actions qui tendent à revendiquer un immeuble.
