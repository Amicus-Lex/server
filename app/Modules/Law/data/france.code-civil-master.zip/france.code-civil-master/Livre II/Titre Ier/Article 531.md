Article 531
----
Les bateaux, bacs, navires, moulins et bains sur bateaux, et généralement toutes
usines non fixées par des piliers, et ne faisant point partie de la maison, sont
meubles : la saisie de quelques-uns de ces objets peut cependant, à cause de
leur importance, être soumises à des formes particulières, ainsi qu'il sera
expliqué dans le code de la procédure civile.
