Article 518
----
Les fonds de terre et les bâtiments sont immeubles par leur nature.
