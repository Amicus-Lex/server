Article 542
----
Les biens communaux sont ceux à la propriété ou au produit desquels les
habitants d'une ou plusieurs communes ont un droit acquis.
