Article 528
----
Sont meubles par leur nature les biens qui peuvent se transporter d'un lieu à un
autre.
