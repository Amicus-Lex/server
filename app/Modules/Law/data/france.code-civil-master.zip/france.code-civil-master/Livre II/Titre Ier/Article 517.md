Article 517
----
Les biens sont immeubles, ou par leur nature, ou par leur destination, ou par
l'objet auquel ils s'appliquent.
