Article 519
----
Les moulins à vent ou à eau, fixés sur piliers et faisant partie du bâtiment,
sont aussi immeubles par leur nature.
