Article 529
----
Sont meubles par la détermination de la loi les obligations et actions qui ont
pour objet des sommes exigibles ou des effets mobiliers, les actions ou intérêts
dans les compagnies de finance, de commerce ou d'industrie, encore que des
immeubles dépendant de ces entreprises appartiennent aux compagnies. Ces actions
ou intérêts sont réputés meubles à l'égard de chaque associé seulement, tant que
dure la société.

Sont aussi meubles par la détermination de la loi les rentes perpétuelles ou
viagères, soit sur l'Etat, soit sur des particuliers.
