Article 543
----
On peut avoir sur les biens, ou un droit de propriété, ou un simple droit de
jouissance, ou seulement des services fonciers à prétendre.
