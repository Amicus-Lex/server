Article 516
----
Tous les biens sont meubles ou immeubles.
