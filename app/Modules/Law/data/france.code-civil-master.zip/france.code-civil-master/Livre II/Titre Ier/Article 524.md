Article 524
----
Les objets que le propriétaire d'un fonds y a placés pour le service et
l'exploitation de ce fonds sont immeubles par destination.

Les animaux que le propriétaire d'un fonds y a placés aux mêmes fins sont soumis
au régime des immeubles par destination.

Ainsi, sont immeubles par destination, quand ils ont été placés par le
propriétaire pour le service et l'exploitation du fonds :

Les ustensiles aratoires ;

Les semences données aux fermiers ou métayers ;

Les ruches à miel ;

Les pressoirs, chaudières, alambics, cuves et tonnes ;

Les ustensiles nécessaires à l'exploitation des forges, papeteries et autres
usines ;

Les pailles et engrais.

Sont aussi immeubles par destination tous effets mobiliers que le propriétaire a
attachés au fonds à perpétuelle demeure.
