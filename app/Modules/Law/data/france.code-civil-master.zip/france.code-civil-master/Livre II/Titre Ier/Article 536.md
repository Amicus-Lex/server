Article 536
----
La vente ou le don d'une maison, avec tout ce qui s'y trouve, ne comprend pas
l'argent comptant, ni les dettes actives et autres droits dont les titres
peuvent être déposés dans la maison ; tous les autres effets mobiliers y sont
compris.
