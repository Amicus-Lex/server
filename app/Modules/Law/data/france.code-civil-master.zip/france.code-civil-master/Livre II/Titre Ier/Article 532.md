Article 532
----
Les matériaux provenant de la démolition d'un édifice, ceux assemblés pour en
construire un nouveau, sont meubles jusqu'à ce qu'ils soient employés par
l'ouvrier dans une construction.
