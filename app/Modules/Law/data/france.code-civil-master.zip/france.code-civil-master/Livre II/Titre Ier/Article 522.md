Article 522
----
Les animaux que le propriétaire du fonds livre au fermier ou au métayer pour la
culture, estimés ou non, sont soumis au régime des immeubles tant qu'ils
demeurent attachés au fonds par l'effet de la convention.

Ceux qu'il donne à cheptel à d'autres qu'au fermier ou métayer sont soumis au
régime des meubles.
