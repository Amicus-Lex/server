Article 527
----
Les biens sont meubles par leur nature ou par la détermination de la loi.
