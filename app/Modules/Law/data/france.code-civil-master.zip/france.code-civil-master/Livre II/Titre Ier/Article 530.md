Article 530
----
Toute rente établie à perpétuité pour le prix de la vente d'un immeuble, ou
comme condition de la cession à titre onéreux ou gratuit d'un fonds immobilier,
est essentiellement rachetable.

Il est néanmoins permis au créancier de régler les clauses et conditions du
rachat.

Il lui est aussi permis de stipuler que la rente ne pourra lui être remboursée
qu'après un certain terme, lequel ne peut jamais excéder trente ans ; toute
stipulation contraire est nulle.
