Article 539
----
Les biens des personnes qui décèdent sans héritiers ou dont les successions sont
abandonnées appartiennent à l'Etat.
